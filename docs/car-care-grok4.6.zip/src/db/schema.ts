import {
  pgTable,
  text,
  timestamp,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";

export const bookings = pgTable("bookings", {
  id: uuid("id").defaultRandom().primaryKey(),
  fullName: varchar("full_name", { length: 120 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 40 }).notNull(),
  vehicleType: varchar("vehicle_type", { length: 40 }).notNull(),
  vehicleYear: varchar("vehicle_year", { length: 8 }),
  vehicleMake: varchar("vehicle_make", { length: 80 }),
  vehicleModel: varchar("vehicle_model", { length: 80 }),
  serviceSlug: varchar("service_slug", { length: 80 }).notNull(),
  locationType: varchar("location_type", { length: 40 }).notNull(),
  address: text("address"),
  zipCode: varchar("zip_code", { length: 10 }),
  preferredDate: varchar("preferred_date", { length: 20 }),
  preferredTime: varchar("preferred_time", { length: 20 }),
  notes: text("notes"),
  status: varchar("status", { length: 24 }).notNull().default("new"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const contactMessages = pgTable("contact_messages", {
  id: uuid("id").defaultRandom().primaryKey(),
  fullName: varchar("full_name", { length: 120 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 40 }),
  topic: varchar("topic", { length: 80 }).notNull(),
  message: text("message").notNull(),
  status: varchar("status", { length: 24 }).notNull().default("new"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const fleetInquiries = pgTable("fleet_inquiries", {
  id: uuid("id").defaultRandom().primaryKey(),
  companyName: varchar("company_name", { length: 160 }).notNull(),
  contactName: varchar("contact_name", { length: 120 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 40 }).notNull(),
  fleetSize: varchar("fleet_size", { length: 40 }).notNull(),
  vehicleTypes: varchar("vehicle_types", { length: 160 }).notNull(),
  servicePreference: varchar("service_preference", { length: 40 }).notNull(),
  notes: text("notes"),
  status: varchar("status", { length: 24 }).notNull().default("new"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const reviews = pgTable("reviews", {
  id: uuid("id").defaultRandom().primaryKey(),
  authorName: varchar("author_name", { length: 80 }).notNull(),
  body: text("body").notNull(),
  publishedOn: varchar("published_on", { length: 24 }).notNull(),
  rating: varchar("rating", { length: 8 }).notNull().default("5"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export type Booking = typeof bookings.$inferSelect;
export type ContactMessage = typeof contactMessages.$inferSelect;
export type FleetInquiry = typeof fleetInquiries.$inferSelect;
export type Review = typeof reviews.$inferSelect;
