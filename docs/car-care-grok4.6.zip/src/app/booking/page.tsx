import type { Metadata } from "next";
import { BookingForm } from "@/components/booking-form";
import { SERVICES } from "@/lib/site";

export const metadata: Metadata = {
  title: "Book Your Detail | We Care Car Care, Framingham MA",
  description:
    "Book your professional auto detailing or ceramic coating appointment with We Care Car Care in Framingham, MA. Easy online scheduling, mobile and shop service.",
};

export default async function BookingPage({
  searchParams,
}: {
  searchParams: Promise<{ service?: string }>;
}) {
  const params = await searchParams;
  const requested = params.service;
  const defaultService = SERVICES.some((item) => item.slug === requested)
    ? requested
    : undefined;

  return (
    <main id="main" className="px-4 pb-24 pt-36 md:px-8">
      <div className="container mx-auto max-w-3xl">
        <h1 className="mb-2 text-center text-4xl font-black md:text-5xl">
          Book Your <span className="text-gold">Detail</span>
        </h1>
        <p className="mb-10 text-center text-muted-foreground">
          Select your service and pick a time that works for you.
        </p>
        <BookingForm defaultService={defaultService} />
      </div>
    </main>
  );
}
