import Link from "next/link";

export default function NotFound() {
  return (
    <main id="main" className="grid min-h-screen place-items-center px-6 pt-32">
      <div className="max-w-lg text-center">
        <p className="mb-3 text-sm font-black uppercase tracking-[0.25em] text-gold">
          404
        </p>
        <h1 className="mb-4 text-4xl font-black">This page took a wrong turn.</h1>
        <p className="mb-8 text-muted-foreground">
          The page you&apos;re looking for isn&apos;t here. Book a detail, browse the
          gallery, or head home.
        </p>
        <div className="flex flex-wrap justify-center gap-3">
          <Link
            href="/"
            className="rounded-2xl border border-border px-6 py-3 font-bold"
          >
            Home
          </Link>
          <Link
            href="/booking"
            className="rounded-2xl bg-gold px-6 py-3 font-black text-gold-foreground"
          >
            Book Your Detail
          </Link>
        </div>
      </div>
    </main>
  );
}
