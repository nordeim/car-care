import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Inter } from "next/font/google";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";
import { MobileBookBar } from "@/components/mobile-book-bar";
import { SITE } from "@/lib/site";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-inter",
});

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "Auto Detailing & Ceramic Coating | Framingham MA",
    template: "%s | We Care Car Care",
  },
  description:
    "Top-rated auto detailing, ceramic coating & paint protection in Framingham and MetroWest MA. 16+ years experience, 5-star rated. Book today!",
  keywords: [
    "auto detailing Framingham MA",
    "ceramic coating Natick",
    "MetroWest auto detailing",
    "paint protection Massachusetts",
    "mobile detailing near me",
  ],
  authors: [{ name: SITE.name }],
  openGraph: {
    type: "website",
    locale: "en_US",
    siteName: SITE.name,
    title: "Auto Detailing & Ceramic Coating | Framingham MA",
    description:
      "Top-rated auto detailing, ceramic coating & paint protection in Framingham & MetroWest MA. 16+ years, 5-star rated. Book today!",
    images: [{ url: "/images/og-image.jpg", width: 1200, height: 630 }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Auto Detailing & Ceramic Coating | Framingham MA",
    description:
      "Professional eco-friendly auto detailing & ceramic coating in Framingham, MA. 16+ years, 5-star rated. Book today!",
    images: ["/images/og-image.jpg"],
  },
  icons: { icon: "/favicon.png" },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={inter.variable}>
      <body className="min-h-screen bg-background font-sans text-foreground antialiased">
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-[60] focus:rounded-md focus:bg-gold focus:px-4 focus:py-2 focus:text-gold-foreground"
        >
          Skip to content
        </a>
        <SiteHeader />
        {children}
        <SiteFooter />
        <MobileBookBar />
      </body>
    </html>
  );
}
