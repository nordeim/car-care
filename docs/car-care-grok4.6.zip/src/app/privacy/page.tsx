import type { Metadata } from "next";
import { SITE } from "@/lib/site";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: `How ${SITE.name} collects and uses appointment and contact information.`,
};

export default function PrivacyPage() {
  return (
    <main id="main" className="px-4 pb-24 pt-36">
      <article className="container mx-auto max-w-3xl">
        <h1 className="mb-6 text-4xl font-black">Privacy Policy</h1>
        <p className="mb-6 text-muted-foreground">
          We Care Car Care collects only what we need to schedule detailing,
          ceramic coating, and fleet work in MetroWest Massachusetts.
        </p>
        <h2 className="mb-3 mt-8 text-2xl font-black">What we collect</h2>
        <p className="text-muted-foreground">
          Name, email, phone, vehicle details, service selection, address/ZIP for
          mobile or pickup jobs, preferred appointment window, and optional notes
          (pet hair, sap, ceramic interest). Fleet inquiries also include company
          name and fleet size.
        </p>
        <h2 className="mb-3 mt-8 text-2xl font-black">How we use it</h2>
        <p className="text-muted-foreground">
          Requests are stored so our team can confirm appointments, prepare the
          right package, and follow up. We do not sell personal information.
        </p>
        <h2 className="mb-3 mt-8 text-2xl font-black">Contact</h2>
        <p className="text-muted-foreground">
          Questions about stored data: {SITE.email} or {SITE.phoneDisplay}. Studio:{" "}
          {SITE.street}, {SITE.city}, {SITE.region} {SITE.postal}.
        </p>
      </article>
    </main>
  );
}
