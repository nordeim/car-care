import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, MapPin, Phone, Truck } from "lucide-react";
import { SITE, TOWNS } from "@/lib/site";

export const metadata: Metadata = {
  title: "Service Areas | Auto Detailing in MetroWest MA",
  description:
    "Auto detailing, ceramic coating & paint protection in Framingham, Natick, Sudbury, Wellesley and across MetroWest MA. Mobile and shop service.",
};

export default function ServiceAreasPage() {
  return (
    <main id="main" className="px-4 pb-24 pt-36">
      <div className="container mx-auto mb-16 text-center">
        <h1 className="mb-4 text-4xl font-black text-foreground md:text-5xl">
          Auto Detailing &amp; Ceramic Coating in{" "}
          <span className="text-primary">MetroWest MA</span>
        </h1>
        <p className="mx-auto max-w-3xl text-lg text-muted-foreground">
          We proudly serve Framingham and surrounding communities with professional
          auto detailing, ceramic coating, and paint protection services. Mobile,
          shop, and pickup/delivery options available.
        </p>
      </div>
      <div className="container mx-auto mb-16 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
        {TOWNS.map((town) => (
          <article
            key={town.name}
            className="rounded-xl border border-border bg-card p-6 transition-colors hover:border-primary/50"
          >
            <div className="mb-3 flex items-start gap-3">
              <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
              <div>
                <h2 className="text-lg font-bold text-foreground">
                  Auto Detailing in {town.name}, MA
                </h2>
                <span className="text-xs text-muted-foreground">{town.zip}</span>
              </div>
            </div>
            <p className="mb-4 text-sm text-muted-foreground">{town.description}</p>
            <p className="mb-2 flex items-center gap-1.5 text-xs font-medium text-primary">
              <Truck className="h-3.5 w-3.5" />
              Free Pickup &amp; Delivery
            </p>
            <p className="text-xs text-muted-foreground">
              Auto Detailing · Ceramic Coating · Paint Protection · Interior Detail
            </p>
          </article>
        ))}
      </div>
      <div className="container mx-auto text-center">
        <div className="mx-auto max-w-2xl rounded-2xl border border-border bg-card p-8 md:p-12">
          <h2 className="mb-3 text-2xl font-bold">Don&apos;t See Your Town?</h2>
          <p className="mb-6 text-muted-foreground">
            We service a {SITE.radius} radius around Framingham. Call us to check
            availability in your area.
          </p>
          <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
            <a
              href={`tel:${SITE.phoneTel}`}
              className="flex items-center gap-2 font-bold text-primary hover:underline"
            >
              <Phone className="h-4 w-4" />
              {SITE.phoneDisplay}
            </a>
            <Link
              href="/booking"
              className="flex items-center gap-2 rounded-xl bg-gold px-6 py-3 text-sm font-black text-gold-foreground"
            >
              Book Your Detail
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </div>
    </main>
  );
}
