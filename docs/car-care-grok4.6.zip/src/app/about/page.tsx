import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, Leaf, Snowflake, Users } from "lucide-react";
import { SITE, TEAM } from "@/lib/site";

export const metadata: Metadata = {
  title: "About We Care Car Care | Framingham, MA",
  description:
    "Meet the team behind We Care Car Care. 16+ years of professional auto detailing expertise in Framingham, MA. Eco-friendly, detail-obsessed, and family-owned.",
};

export default function AboutPage() {
  return (
    <main id="main">
      <section className="relative overflow-hidden px-4 pb-16 pt-36 md:px-8">
        <Image
          src="/images/shop-interior.jpg"
          alt="We Care Car Care detailing studio interior"
          fill
          className="scale-[1.02] object-cover blur-[2px]"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background/85 via-background/60 to-background/30" />
        <div className="container relative z-10 mx-auto max-w-5xl text-center">
          <p className="mb-4 inline-block text-sm font-black uppercase tracking-[0.25em] text-gold">
            Our Story
          </p>
          <h1 className="mb-6 text-5xl font-black leading-[0.95] tracking-tight md:text-7xl">
            <span className="sr-only">
              About We Care Car Care — Our Story &amp; Team in Framingham, MA —{" "}
            </span>
            <span aria-hidden="true">
              Built on <span className="text-gradient">Passion.</span>
              <br />
              Driven by <span className="text-gold">Care.</span>
            </span>
          </h1>
        </div>
      </section>

      <section className="px-4 py-16 md:px-8">
        <div className="container mx-auto grid max-w-5xl items-start gap-12 md:grid-cols-2">
          <div>
            <div className="mb-6 flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gold/10">
                <Leaf className="h-5 w-5 text-gold" />
              </div>
              <h2 className="text-2xl font-black md:text-3xl">How It Started</h2>
            </div>
            <p className="mb-6 leading-relaxed text-foreground/70">
              We Care Car Care began in 2010 when a passionate car enthusiast grew
              frustrated with the lack of thorough, friendly, and convenient auto
              detailing services. Driven to make a change, We Care Car Care was
              born — a mobile detailing company designed to provide top-tier
              services at the location of your choice.
            </p>
            <p className="leading-relaxed text-foreground/70">
              Convenience has always been at the heart of what we do. In the warmer
              months, our self-contained mobile units bring the shine to you, using
              an innovative rinse-less washing system paired with interior steam
              cleaning. This eco-friendly method eliminates the need for harsh
              chemicals and drastically reduces water waste — using less than one
              gallon per vehicle on average.
            </p>
          </div>
          <div>
            <div className="mb-6 flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
                <Snowflake className="h-5 w-5 text-primary" />
              </div>
              <h2 className="text-2xl font-black md:text-3xl">Year-Round Service</h2>
            </div>
            <p className="mb-6 leading-relaxed text-foreground/70">
              In the winter months, we offer complimentary pickup and drop-off
              services, bringing your car to our shop for meticulous detailing.
              Whether at your location or ours, you can count on us to deliver
              exceptional results all year long.
            </p>
            <div className="mb-6 mt-10 flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
                <Users className="h-5 w-5 text-primary" />
              </div>
              <h2 className="text-2xl font-black md:text-3xl">Our Team</h2>
            </div>
            <p className="leading-relaxed text-foreground/70">
              Our team consists of dedicated professionals and seasonal employees,
              many of whom are college students with diverse skill sets and a
              shared love for cars. We take pride in providing in-depth training,
              ensuring every team member gains hands-on experience in detailing,
              sales, marketing, operations, and customer service. Beyond their
              technical expertise, our team values honesty, care, and the kind of
              finish you notice the moment you sit down.
            </p>
          </div>
        </div>
      </section>

      <section className="px-4 pb-24 md:px-8">
        <div className="container mx-auto max-w-5xl">
          <h2 className="mb-10 text-center text-4xl font-black">
            Meet the <span className="text-gradient">people</span> behind the shine
          </h2>
          <div className="grid gap-8 md:grid-cols-3">
            {TEAM.map((member) => (
              <article
                key={member.name}
                className="overflow-hidden rounded-[28px] border border-border bg-card"
              >
                <Image
                  src={member.image}
                  alt={`${member.name}, ${member.role} at We Care Car Care`}
                  width={640}
                  height={800}
                  className="h-72 w-full object-cover object-top"
                />
                <div className="p-6">
                  <p className="text-xs font-bold uppercase tracking-[0.16em] text-gold">
                    {member.role}
                  </p>
                  <h3 className="mt-1 text-xl font-black">{member.name}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                    {member.bio}
                  </p>
                </div>
              </article>
            ))}
          </div>
          <div className="mt-14 text-center">
            <p className="mb-6 text-muted-foreground">
              Join the {SITE.vehiclesDetailed} vehicles we&apos;ve detailed with
              care and precision.
            </p>
            <Link
              href="/booking"
              className="inline-flex items-center gap-2 rounded-2xl bg-gold px-10 py-4 font-black text-gold-foreground"
            >
              Book Your Detail
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}
