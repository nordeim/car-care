import type { Metadata } from "next";
import Image from "next/image";
import { Mail, MapPin, MessageCircle, Phone } from "lucide-react";
import { ContactForm } from "@/components/contact-form";
import { SITE } from "@/lib/site";

export const metadata: Metadata = {
  title: "Contact We Care Car Care | Framingham, MA",
  description:
    "Get in touch with We Care Car Care in Framingham, MA. Schedule your auto detailing or ceramic coating appointment, call, email, or fill out our contact form.",
};

export default function ContactPage() {
  return (
    <main id="main">
      <section className="px-4 pb-12 pt-36">
        <div className="container mx-auto text-center">
          <h1 className="mb-4 text-4xl font-black md:text-5xl">
            Get In <span className="text-primary">Touch</span>
          </h1>
          <p className="mx-auto max-w-xl text-lg text-muted-foreground">
            Have a question or ready to book? We&apos;re happy to help.
          </p>
        </div>
      </section>

      <section className="px-4 pb-16">
        <div className="container mx-auto grid max-w-4xl gap-6 sm:grid-cols-3">
          <a
            href={`tel:${SITE.phoneTel}`}
            className="warm-shadow rounded-2xl border border-border bg-card p-8 text-center transition-all hover:border-primary/30"
          >
            <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-full bg-primary/15">
              <Phone className="h-6 w-6 text-primary" />
            </div>
            <h2 className="mb-2 text-lg font-extrabold">Call or Text</h2>
            <p className="text-lg font-bold text-primary">{SITE.phoneDisplay}</p>
          </a>
          <a
            href={`mailto:${SITE.email}`}
            className="warm-shadow rounded-2xl border border-border bg-card p-8 text-center transition-all hover:border-primary/30"
          >
            <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-full bg-primary/15">
              <Mail className="h-6 w-6 text-primary" />
            </div>
            <h2 className="mb-2 text-lg font-extrabold">Email</h2>
            <p className="text-sm font-bold text-primary">{SITE.email}</p>
          </a>
          <a
            href="/booking"
            className="warm-shadow rounded-2xl border border-border bg-card p-8 text-center transition-all hover:border-primary/30"
          >
            <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-full bg-primary/15">
              <MessageCircle className="h-6 w-6 text-primary" />
            </div>
            <h2 className="mb-2 text-lg font-extrabold">Ask a Question</h2>
            <p className="mb-4 text-sm text-muted-foreground">
              Get instant answers, pricing, or help booking
            </p>
            <span className="text-sm font-bold text-primary">Start booking →</span>
          </a>
        </div>
      </section>

      <section className="px-4 pb-20">
        <div className="container mx-auto max-w-5xl">
          <h2 className="mb-10 text-center text-3xl font-black md:text-4xl">
            Visit Our <span className="text-primary">Shop</span>
          </h2>
          <div className="grid items-center gap-8 md:grid-cols-2">
            <div className="space-y-6">
              <div className="warm-shadow rounded-2xl border border-border bg-card p-8">
                <div className="flex items-start gap-4">
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary/15">
                    <MapPin className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="mb-1 text-lg font-extrabold">Detail Studio</h3>
                    <p className="leading-relaxed text-muted-foreground">
                      {SITE.street}
                      <br />
                      {SITE.city}, {SITE.region} {SITE.postal}
                    </p>
                    <p className="mt-2 text-sm text-muted-foreground">{SITE.hours}</p>
                  </div>
                </div>
              </div>
              <div className="h-[220px] overflow-hidden rounded-2xl border border-border">
                <iframe
                  title="We Care Car Care Location"
                  src="https://maps.google.com/maps?q=874%20Edgell%20Rd%20Framingham%20MA%2001701&t=&z=15&ie=UTF8&iwloc=&output=embed"
                  className="h-full w-full grayscale invert-[0.9] contrast-90"
                  loading="lazy"
                />
              </div>
            </div>
            <div className="grid grid-rows-2 gap-4">
              <Image
                src="/images/shop-exterior.jpg"
                alt="We Care Car Care detail studio exterior"
                width={800}
                height={400}
                className="h-[200px] w-full rounded-2xl border border-border object-cover"
              />
              <Image
                src="/images/shop-interior.jpg"
                alt="We Care Car Care detail studio interior with vehicle"
                width={800}
                height={400}
                className="h-[200px] w-full rounded-2xl border border-border object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="px-4 pb-24">
        <div className="container mx-auto mb-8 max-w-3xl text-center">
          <h2 className="mb-2 text-3xl font-black md:text-4xl">
            Want us to <span className="text-primary">reach out</span>?
          </h2>
          <p className="text-muted-foreground">
            Fill this out and we&apos;ll follow up with pricing and availability.
          </p>
        </div>
        <div className="container mx-auto max-w-3xl">
          <ContactForm />
        </div>
      </section>
    </main>
  );
}
