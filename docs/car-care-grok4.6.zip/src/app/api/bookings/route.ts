import { NextRequest } from "next/server";
import { db } from "@/db";
import { bookings } from "@/db/schema";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import {
  asRecord,
  formatPhone,
  inList,
  isEmail,
  isZip,
  normalizePhone,
  optionalStr,
  str,
} from "@/lib/validation";
import {
  LOCATION_TYPES,
  SERVICES,
  TIME_WINDOWS,
  VEHICLE_TYPES,
} from "@/lib/site";

export const dynamic = "force-dynamic";

const SERVICE_SLUGS = SERVICES.map((item) => item.slug);
const LOCATION_VALUES = LOCATION_TYPES.map((item) => item.value);

export async function POST(request: NextRequest) {
  const limited = rateLimit(`book:${clientIp(request.headers)}`, 8, 10 * 60 * 1000);
  if (!limited.ok) {
    return Response.json(
      { error: "Too many booking requests. Please wait and try again." },
      { status: 429, headers: { "Retry-After": String(limited.retryAfterSec) } },
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Invalid JSON." }, { status: 400 });
  }

  const record = asRecord(body);
  if (!record) {
    return Response.json({ error: "Expected a JSON object." }, { status: 400 });
  }

  const fullName = str(record.fullName, 120);
  const email = str(record.email, 255);
  const phoneRaw = str(record.phone, 40);
  const vehicleType = str(record.vehicleType, 40);
  const serviceSlug = str(record.serviceSlug, 80);
  const locationType = str(record.locationType, 40);
  const preferredDate = optionalStr(record.preferredDate, 20);
  const preferredTime = optionalStr(record.preferredTime, 20);
  const zipCode = optionalStr(record.zipCode, 10);
  const notes = optionalStr(record.notes, 2000);
  const address = optionalStr(record.address, 240);
  const vehicleYear = optionalStr(record.vehicleYear, 8);
  const vehicleMake = optionalStr(record.vehicleMake, 80);
  const vehicleModel = optionalStr(record.vehicleModel, 80);

  if (!fullName || !email || !phoneRaw || !vehicleType || !serviceSlug || !locationType) {
    return Response.json({ error: "Missing required booking fields." }, { status: 400 });
  }
  if (!isEmail(email)) {
    return Response.json({ error: "Enter a valid email address." }, { status: 400 });
  }
  const phoneDigits = normalizePhone(phoneRaw);
  if (!phoneDigits) {
    return Response.json({ error: "Enter a valid 10-digit phone number." }, { status: 400 });
  }
  if (!inList(vehicleType, VEHICLE_TYPES)) {
    return Response.json({ error: "Unknown vehicle type." }, { status: 400 });
  }
  if (!inList(serviceSlug, SERVICE_SLUGS)) {
    return Response.json({ error: "Unknown service." }, { status: 400 });
  }
  if (!inList(locationType, LOCATION_VALUES)) {
    return Response.json({ error: "Unknown location type." }, { status: 400 });
  }
  if (locationType !== "shop") {
    if (!zipCode || !isZip(zipCode)) {
      return Response.json(
        { error: "A 5-digit ZIP is required for mobile and pickup service." },
        { status: 400 },
      );
    }
  }
  if (preferredTime && !inList(preferredTime, TIME_WINDOWS)) {
    return Response.json({ error: "Unknown time window." }, { status: 400 });
  }

  try {
    const [row] = await db
      .insert(bookings)
      .values({
        fullName,
        email: email.toLowerCase(),
        phone: formatPhone(phoneDigits),
        vehicleType,
        vehicleYear,
        vehicleMake,
        vehicleModel,
        serviceSlug,
        locationType,
        address,
        zipCode,
        preferredDate,
        preferredTime,
        notes,
      })
      .returning({ id: bookings.id });

    if (!row) {
      return Response.json({ error: "Could not save booking." }, { status: 500 });
    }
    return Response.json({ ok: true, id: row.id });
  } catch {
    return Response.json({ error: "Database unavailable." }, { status: 500 });
  }
}
