import { NextRequest } from "next/server";
import { db } from "@/db";
import { contactMessages } from "@/db/schema";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import {
  asRecord,
  formatPhone,
  isEmail,
  normalizePhone,
  optionalStr,
  str,
} from "@/lib/validation";

export const dynamic = "force-dynamic";

const TOPICS = [
  "Pricing & availability",
  "Ceramic coating",
  "Mobile / pickup questions",
  "Something else",
] as const;

export async function POST(request: NextRequest) {
  const limited = rateLimit(`contact:${clientIp(request.headers)}`, 8, 10 * 60 * 1000);
  if (!limited.ok) {
    return Response.json(
      { error: "Too many messages. Please wait and try again." },
      { status: 429, headers: { "Retry-After": String(limited.retryAfterSec) } },
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Invalid JSON." }, { status: 400 });
  }
  const record = asRecord(body);
  if (!record) {
    return Response.json({ error: "Expected a JSON object." }, { status: 400 });
  }

  const fullName = str(record.fullName, 120);
  const email = str(record.email, 255);
  const topic = str(record.topic, 80);
  const message = str(record.message, 4000);
  const phoneRaw = optionalStr(record.phone, 40);

  if (!fullName || !email || !topic || !message) {
    return Response.json({ error: "Name, email, topic, and message are required." }, { status: 400 });
  }
  if (!isEmail(email)) {
    return Response.json({ error: "Enter a valid email address." }, { status: 400 });
  }
  if (!(TOPICS as readonly string[]).includes(topic)) {
    return Response.json({ error: "Unknown topic." }, { status: 400 });
  }
  let phone: string | null = null;
  if (phoneRaw) {
    const digits = normalizePhone(phoneRaw);
    if (!digits) {
      return Response.json({ error: "Enter a valid phone number." }, { status: 400 });
    }
    phone = formatPhone(digits);
  }

  try {
    const [row] = await db
      .insert(contactMessages)
      .values({
        fullName,
        email: email.toLowerCase(),
        phone,
        topic,
        message,
      })
      .returning({ id: contactMessages.id });
    if (!row) {
      return Response.json({ error: "Could not save message." }, { status: 500 });
    }
    return Response.json({ ok: true, id: row.id });
  } catch {
    return Response.json({ error: "Database unavailable." }, { status: 500 });
  }
}
