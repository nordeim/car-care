import { NextRequest } from "next/server";
import { db } from "@/db";
import { fleetInquiries } from "@/db/schema";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import {
  asRecord,
  formatPhone,
  isEmail,
  normalizePhone,
  optionalStr,
  str,
} from "@/lib/validation";

export const dynamic = "force-dynamic";

const SIZES = ["1–5", "6–15", "16–40", "40+"] as const;
const TYPES = [
  "Executive cars",
  "Service vans / trucks",
  "Mixed fleet",
  "Campus / school vehicles",
] as const;
const PREFS = ["On-site", "Shop", "Either"] as const;

export async function POST(request: NextRequest) {
  const limited = rateLimit(`fleet:${clientIp(request.headers)}`, 6, 10 * 60 * 1000);
  if (!limited.ok) {
    return Response.json(
      { error: "Too many fleet requests. Please wait and try again." },
      { status: 429, headers: { "Retry-After": String(limited.retryAfterSec) } },
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Invalid JSON." }, { status: 400 });
  }
  const record = asRecord(body);
  if (!record) {
    return Response.json({ error: "Expected a JSON object." }, { status: 400 });
  }

  const companyName = str(record.companyName, 160);
  const contactName = str(record.contactName, 120);
  const email = str(record.email, 255);
  const phoneRaw = str(record.phone, 40);
  const fleetSize = str(record.fleetSize, 40);
  const vehicleTypes = str(record.vehicleTypes, 160);
  const servicePreference = str(record.servicePreference, 40);
  const notes = optionalStr(record.notes, 2000);

  if (
    !companyName ||
    !contactName ||
    !email ||
    !phoneRaw ||
    !fleetSize ||
    !vehicleTypes ||
    !servicePreference
  ) {
    return Response.json({ error: "Missing required fleet fields." }, { status: 400 });
  }
  if (!isEmail(email)) {
    return Response.json({ error: "Enter a valid email address." }, { status: 400 });
  }
  const phoneDigits = normalizePhone(phoneRaw);
  if (!phoneDigits) {
    return Response.json({ error: "Enter a valid 10-digit phone number." }, { status: 400 });
  }
  if (!(SIZES as readonly string[]).includes(fleetSize)) {
    return Response.json({ error: "Unknown fleet size." }, { status: 400 });
  }
  if (!(TYPES as readonly string[]).includes(vehicleTypes)) {
    return Response.json({ error: "Unknown vehicle mix." }, { status: 400 });
  }
  if (!(PREFS as readonly string[]).includes(servicePreference)) {
    return Response.json({ error: "Unknown service preference." }, { status: 400 });
  }

  try {
    const [row] = await db
      .insert(fleetInquiries)
      .values({
        companyName,
        contactName,
        email: email.toLowerCase(),
        phone: formatPhone(phoneDigits),
        fleetSize,
        vehicleTypes,
        servicePreference,
        notes,
      })
      .returning({ id: fleetInquiries.id });
    if (!row) {
      return Response.json({ error: "Could not save inquiry." }, { status: 500 });
    }
    return Response.json({ ok: true, id: row.id });
  } catch {
    return Response.json({ error: "Database unavailable." }, { status: 500 });
  }
}
