import type { Metadata } from "next";
import Link from "next/link";
import {
  ArrowRight,
  Building2,
  Car,
  Check,
  Droplets,
  Phone,
  Shield,
  Sparkles,
  Truck,
} from "lucide-react";
import { FleetForm } from "@/components/fleet-form";
import {
  FLEET_ADDONS,
  FLEET_CLIENTS,
  FLEET_CORPORATE,
  FLEET_EXTERIOR,
  FLEET_INTERIOR,
  FLEET_REASONS,
  FLEET_STEPS,
  FLEET_VEHICLES,
  SITE,
} from "@/lib/site";

export const metadata: Metadata = {
  title: "Fleet Vehicle Care | Framingham MA",
  description:
    "Corporate and fleet vehicle care for MetroWest businesses. On-site or shop service for executive cars, service vans and school fleets.",
};

export default function FleetPage() {
  return (
    <main id="main">
      <section className="relative overflow-hidden bg-background px-4 pb-20 pt-36 md:pb-28">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-gold/5" />
        <div className="container relative z-10 mx-auto max-w-5xl">
          <p className="mb-6 inline-block text-sm font-black uppercase tracking-[0.25em] text-gold">
            Corporate &amp; Fleet Services
          </p>
          <h1 className="mb-6 text-4xl font-black leading-[0.95] tracking-tight md:text-6xl lg:text-7xl">
            Professional Vehicles.{" "}
            <span className="text-gradient">Consistently Maintained.</span>
          </h1>
          <p className="mb-8 max-w-2xl text-lg text-muted-foreground md:text-xl">
            We help businesses keep their vehicles clean, presentable, and protected
            — whether it&apos;s a single executive vehicle or a full fleet.
          </p>
          <p className="mb-8 font-semibold text-foreground/80">
            Trusted by local organizations including{" "}
            <span className="text-gold">Bose</span> and{" "}
            <span className="text-gold">Dana Hall School</span>, along with service
            companies throughout MetroWest.
          </p>
          <div className="mb-10 flex flex-wrap gap-6 text-sm font-semibold text-foreground/80">
            <span className="flex items-center gap-2">
              <Check className="h-4 w-4 text-primary" /> On-site service available
            </span>
            <span className="flex items-center gap-2">
              <Check className="h-4 w-4 text-primary" /> Shop service available
            </span>
            <span className="flex items-center gap-2">
              <Check className="h-4 w-4 text-primary" /> Simple, reliable scheduling
            </span>
          </div>
          <div className="flex flex-col gap-4 sm:flex-row">
            <a
              href="#fleet-quote"
              className="group inline-flex items-center justify-center gap-3 rounded-2xl bg-gold px-10 py-4 font-black text-gold-foreground"
            >
              Request a Fleet Plan
              <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
            </a>
            <a
              href={`tel:${SITE.phoneTel}`}
              className="inline-flex items-center justify-center gap-2 rounded-2xl border border-border px-8 py-4 text-lg font-black hover:bg-white/10"
            >
              <Phone className="h-5 w-5" />
              {SITE.phoneDisplay}
            </a>
          </div>
        </div>
      </section>

      <section className="bg-card px-4 py-20">
        <div className="container mx-auto max-w-5xl">
          <h2 className="mb-4 text-3xl font-black md:text-5xl">
            Who This Is <span className="text-gradient">For</span>
          </h2>
          <p className="mb-10 max-w-2xl text-lg text-muted-foreground">
            Whether you manage a few vehicles or an entire fleet, we make it easy to
            keep everything looking right.
          </p>
          <div className="grid gap-8 md:grid-cols-2">
            <div className="rounded-2xl border border-border bg-secondary/50 p-8">
              <div className="mb-6 flex items-center gap-3">
                <Building2 className="h-6 w-6 text-gold" />
                <h3 className="text-xl font-bold">Corporate Vehicles</h3>
              </div>
              <ul className="space-y-4">
                {FLEET_CORPORATE.map((item) => (
                  <li key={item} className="flex items-start gap-3 font-medium">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-gold" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="rounded-2xl border border-border bg-secondary/50 p-8">
              <div className="mb-6 flex items-center gap-3">
                <Truck className="h-6 w-6 text-primary" />
                <h3 className="text-xl font-bold">Fleet Vehicles</h3>
              </div>
              <ul className="space-y-4">
                {FLEET_VEHICLES.map((item) => (
                  <li key={item} className="flex items-start gap-3 font-medium">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-background px-4 py-20">
        <div className="container mx-auto max-w-5xl">
          <h2 className="mb-4 text-3xl font-black md:text-5xl">
            What We <span className="text-gradient">Do</span>
          </h2>
          <p className="mb-12 max-w-2xl text-lg text-muted-foreground">
            We focus on keeping vehicles clean, consistent, and easy to maintain —
            without overcomplicating things.
          </p>
          <div className="grid gap-8 md:grid-cols-3">
            <div className="rounded-2xl border border-border bg-card p-8">
              <Droplets className="mb-4 h-8 w-8 text-primary" />
              <h3 className="mb-4 text-xl font-bold">Exterior Care</h3>
              <ul className="space-y-3">
                {FLEET_EXTERIOR.map((item) => (
                  <li
                    key={item}
                    className="flex items-start gap-2 text-sm text-muted-foreground"
                  >
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="rounded-2xl border border-border bg-card p-8">
              <Car className="mb-4 h-8 w-8 text-gold" />
              <h3 className="mb-4 text-xl font-bold">Interior Care</h3>
              <ul className="space-y-3">
                {FLEET_INTERIOR.map((item) => (
                  <li
                    key={item}
                    className="flex items-start gap-2 text-sm text-muted-foreground"
                  >
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-gold" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="rounded-2xl border border-border bg-card p-8">
              <Sparkles className="mb-4 h-8 w-8 text-primary" />
              <h3 className="mb-4 text-xl font-bold">Protection &amp; Add-ons</h3>
              <ul className="space-y-3">
                {FLEET_ADDONS.map((item) => (
                  <li
                    key={item}
                    className="flex items-start gap-2 text-sm text-muted-foreground"
                  >
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-card px-4 py-20">
        <div className="container mx-auto max-w-5xl">
          <h2 className="mb-10 text-3xl font-black md:text-5xl">
            Why businesses <span className="text-gradient">stay with us</span>
          </h2>
          <div className="grid gap-6 md:grid-cols-2">
            {FLEET_REASONS.map((item) => (
              <article
                key={item.title}
                className="rounded-2xl border border-border bg-background p-8"
              >
                <Shield className="mb-4 h-6 w-6 text-gold" />
                <h3 className="mb-2 text-xl font-bold">{item.title}</h3>
                <p className="text-muted-foreground">{item.desc}</p>
              </article>
            ))}
          </div>
          <div className="mt-12">
            <p className="mb-4 text-sm font-bold uppercase tracking-[0.16em] text-muted-foreground">
              Trusted locally
            </p>
            <div className="flex flex-wrap gap-3">
              {FLEET_CLIENTS.map((name) => (
                <span
                  key={name}
                  className="rounded-full border border-border bg-secondary px-4 py-2 text-sm font-semibold"
                >
                  {name}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="px-4 py-20">
        <div className="container mx-auto max-w-5xl">
          <h2 className="mb-10 text-3xl font-black md:text-5xl">How it works</h2>
          <div className="grid gap-6 md:grid-cols-3">
            {FLEET_STEPS.map((step) => (
              <article
                key={step.num}
                className="rounded-2xl border border-border bg-card p-8"
              >
                <p className="mb-3 text-3xl font-black text-gold">{step.num}</p>
                <h3 className="mb-2 text-xl font-bold">{step.title}</h3>
                <p className="text-muted-foreground">{step.desc}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="px-4 pb-24">
        <div className="container mx-auto mb-8 max-w-3xl text-center">
          <h2 className="mb-3 text-3xl font-black md:text-4xl">
            Request a <span className="text-gold">fleet plan</span>
          </h2>
          <p className="text-muted-foreground">
            Tell us about your vehicles. We&apos;ll come back with a clear,
            straightforward quote.
          </p>
        </div>
        <div className="container mx-auto max-w-3xl">
          <FleetForm />
        </div>
        <p className="mt-8 text-center">
          Prefer to talk first?{" "}
          <Link href="/contact" className="font-bold text-primary hover:underline">
            Contact the studio
          </Link>
          .
        </p>
      </section>
    </main>
  );
}
