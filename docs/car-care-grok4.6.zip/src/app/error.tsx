"use client";

export default function ErrorPage({
  retry,
  reset,
}: {
  error: Error & { digest?: string };
  retry?: () => void;
  reset?: () => void;
}) {
  const recover = retry ?? reset;

  return (
    <main id="main" className="grid min-h-[70vh] place-items-center px-6 pt-32">
      <div className="max-w-lg text-center">
        <p className="mb-3 text-sm font-black uppercase tracking-[0.25em] text-gold">
          Something went wrong
        </p>
        <h1 className="mb-4 text-3xl font-black">We hit a snag.</h1>
        <p className="mb-8 text-muted-foreground">
          Refresh and try again. If it keeps happening, call (508) 290-7476.
        </p>
        <button
          type="button"
          onClick={() => recover?.()}
          className="rounded-2xl bg-gold px-6 py-3 font-black text-gold-foreground"
        >
          Try again
        </button>
      </div>
    </main>
  );
}
