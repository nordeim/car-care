import type { Metadata } from "next";
import { GalleryGrid } from "@/components/gallery-grid";

export const metadata: Metadata = {
  title: "Detailing Gallery | We Care Car Care, Framingham MA",
  description:
    "See real before-and-after auto detailing and ceramic coating results from We Care Car Care in Framingham, MA. Browse our latest work and transformations.",
};

export default function GalleryPage() {
  return (
    <main id="main" className="px-4 pb-20 pt-36">
      <div className="container mx-auto mb-12 text-center">
        <h1 className="mb-4 text-4xl font-black text-foreground md:text-5xl">
          Our <span className="text-primary">Work</span>
        </h1>
        <p className="mx-auto max-w-2xl text-muted-foreground">
          Real results from real details. Follow us on Instagram and Google to see
          our latest transformations.
        </p>
      </div>
      <GalleryGrid />
      <p className="container mx-auto mt-12 text-center text-sm text-muted-foreground">
        More photos added regularly — check back soon!
      </p>
    </main>
  );
}
