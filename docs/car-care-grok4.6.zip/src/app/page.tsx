import Image from "next/image";
import Link from "next/link";
import { desc } from "drizzle-orm";
import {
  ArrowRight,
  Check,
  MessageCircle,
  Phone,
  Sparkles,
  Star,
} from "lucide-react";
import { FaqJsonLd, LocalBusinessJsonLd } from "@/components/json-ld";
import { FaqList } from "@/components/faq-list";
import { db } from "@/db";
import { reviews } from "@/db/schema";
import { ensureSeeded } from "@/lib/ensure-seeded";
import {
  CERAMIC_ADDON,
  CERAMIC_TIERS,
  CERAMIC_WHY,
  DETAIL_PACKAGES,
  INTERIOR_ONLY,
  REVIEW_SEEDS,
  SITE,
} from "@/lib/site";

export const dynamic = "force-dynamic";

async function loadReviews() {
  try {
    await ensureSeeded();
    const rows = await db
      .select()
      .from(reviews)
      .orderBy(desc(reviews.createdAt));
    if (rows.length > 0) {
      return rows.map((row) => ({
        authorName: row.authorName,
        body: row.body,
        publishedOn: row.publishedOn,
      }));
    }
  } catch {
    // File-backed reviews still render if Postgres is empty or unreachable.
  }
  return REVIEW_SEEDS;
}

export default async function HomePage() {
  const testimonials = await loadReviews();

  return (
    <main id="main">
      <LocalBusinessJsonLd />
      <FaqJsonLd />

      <section className="relative min-h-[92vh] overflow-hidden">
        <Image
          src="/images/hero-wash.jpg"
          alt="Professional auto detailing in progress at We Care Car Care Framingham MA"
          fill
          priority
          className="scale-[1.02] object-cover blur-[2px]"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background/90 via-background/65 to-background/30" />
        <div className="container relative z-10 mx-auto px-4 pb-16 pt-36 md:px-8 md:pt-40">
          <div className="max-w-3xl">
            <p className="mb-6 mt-4 inline-block text-sm font-black uppercase tracking-[0.25em] text-gold">
              Why We&apos;re Different
            </p>
            <h1 className="mb-8 text-5xl font-black leading-[0.9] tracking-tight md:text-7xl lg:text-8xl">
              <span className="sr-only">
                Professional Auto Detailing &amp; Ceramic Coating in Framingham,
                MA —{" "}
              </span>
              <span className="block" aria-hidden="true">
                We Don&apos;t
              </span>
              <span className="block" aria-hidden="true">
                Cut Corners.
              </span>
              <span className="text-gradient mt-2 block" aria-hidden="true">
                Ever.
              </span>
            </h1>
            <div className="mb-8">
              <p className="mb-2 text-2xl font-bold md:text-3xl">
                Your Car Deserves <span className="text-gold">Better.</span>
              </p>
              <p className="text-lg font-semibold text-foreground/80 md:text-xl">
                {SITE.tagline}
              </p>
              <p className="text-lg font-semibold uppercase tracking-wide text-gold md:text-xl">
                Mobile · Shop · Pickup &amp; Delivery
              </p>
            </div>
            <div className="mb-4 flex flex-col gap-4 sm:flex-row">
              <Link
                href="/booking"
                className="gold-glow group inline-flex items-center justify-center gap-3 rounded-2xl bg-gold px-12 py-5 text-lg font-black text-gold-foreground hover:brightness-110"
              >
                Book Your Detail
                <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
              </Link>
              <Link
                href="/contact"
                className="inline-flex items-center justify-center gap-2 rounded-2xl border border-white/30 px-8 py-5 text-lg font-black backdrop-blur-sm hover:bg-white/10"
              >
                <MessageCircle className="h-5 w-5" />
                Ask A Question
              </Link>
            </div>
            <div className="mb-10 mt-3 flex items-center gap-2">
              <Phone className="h-6 w-6 text-gold" />
              <div className="flex flex-col leading-tight">
                <span className="text-sm font-normal text-white">
                  Call or Text Now
                </span>
                <a
                  href={`tel:${SITE.phoneTel}`}
                  className="text-[1.3rem] font-bold text-white hover:underline"
                >
                  {SITE.phoneDisplay}
                </a>
              </div>
            </div>
            <div className="flex flex-wrap gap-8">
              {[
                { number: SITE.years, label: "Years in Business" },
                { number: SITE.vehiclesDetailed, label: "Vehicles Detailed" },
                { number: SITE.rating, label: "Star Rating" },
              ].map((stat) => (
                <div key={stat.label}>
                  <div className="text-4xl font-black text-gold md:text-5xl">
                    {stat.number}
                  </div>
                  <div className="mt-1 text-sm font-semibold text-white/70">
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="bg-ink px-4 py-20 md:px-8 md:py-28">
        <div className="container mx-auto max-w-6xl">
          <div className="mb-12 text-center">
            <p className="mb-4 text-sm font-extrabold uppercase tracking-[0.2em] text-gold">
              Real Results — Not Quick Cleanups
            </p>
            <h2 className="mb-4 text-4xl font-extrabold md:text-6xl">
              This is what a <span className="text-gradient">real detail</span>{" "}
              looks like.
            </h2>
            <p className="mx-auto max-w-3xl text-lg text-muted-foreground">
              Most vehicles we see haven&apos;t been properly detailed in months
              — sometimes years. This isn&apos;t a quick wipe-down. This is a
              true, professional reset — inside and out.
            </p>
          </div>
          <div className="grid gap-6 md:grid-cols-2">
            <figure className="overflow-hidden rounded-[28px] border border-border">
              <Image
                src="/images/before-interior.jpg"
                alt="Interior before professional detailing"
                width={900}
                height={700}
                className="h-72 w-full object-cover md:h-[420px]"
              />
              <figcaption className="bg-card px-5 py-3 text-sm font-bold uppercase tracking-[0.14em] text-muted-foreground">
                Interior Transformation
              </figcaption>
            </figure>
            <figure className="overflow-hidden rounded-[28px] border border-border">
              <Image
                src="/images/after-interior.jpg"
                alt="Interior after professional detailing"
                width={900}
                height={700}
                className="h-72 w-full object-cover md:h-[420px]"
              />
              <figcaption className="bg-card px-5 py-3 text-sm font-bold uppercase tracking-[0.14em] text-gold">
                Exterior Transformation
              </figcaption>
            </figure>
          </div>
          <p className="mt-6 text-center text-sm text-muted-foreground">
            Real customer vehicles — no filters, no tricks.
          </p>
          <div className="mt-8 text-center">
            <Link
              href="#pricing"
              className="inline-flex items-center gap-2 font-black text-gold hover:underline"
            >
              View Packages &amp; Pricing
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      <section id="pricing" className="scroll-mt-28 px-4 py-20 md:px-8 md:py-28">
        <div className="container mx-auto">
          <div className="mb-14 text-center">
            <p className="mb-4 text-sm font-extrabold uppercase tracking-[0.2em] text-gold">
              Transparent Pricing — No Surprises
            </p>
            <h2 className="mb-4 text-4xl font-extrabold md:text-6xl">
              Choose Your Level of <span className="text-gradient">Care</span>
            </h2>
            <p className="text-muted-foreground">
              No shortcuts. No hidden fees. Just real results.
            </p>
            <p className="mt-2 text-sm font-semibold text-gold">
              Most customers choose the Premium package for the best overall
              result.
            </p>
          </div>
          <div className="mx-auto grid max-w-6xl gap-8 lg:grid-cols-2">
            {DETAIL_PACKAGES.map((pkg) => (
              <article
                key={pkg.slug}
                className={`relative overflow-hidden rounded-[28px] border bg-card ${
                  pkg.featured ? "border-gold/50" : "border-border"
                }`}
              >
                {pkg.badge ? (
                  <div className="absolute left-1/2 top-4 z-10 -translate-x-1/2 rounded-full bg-gold/90 px-5 py-1.5 text-[11px] font-black uppercase tracking-[0.15em] text-background">
                    {pkg.badge}
                  </div>
                ) : null}
                <Image
                  src={pkg.image}
                  alt={pkg.imageAlt}
                  width={900}
                  height={520}
                  className="h-56 w-full object-cover"
                />
                <div className="p-7 md:p-9">
                  <h3 className="text-2xl font-black">{pkg.name}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">
                    {pkg.description}
                  </p>
                  <div className="mt-6 flex gap-8">
                    <Price label="Sedan" value={pkg.sedanPrice} />
                    <Price label="SUV / Truck" value={pkg.suvPrice} />
                  </div>
                  <ul className="mt-6 grid gap-2">
                    {[...pkg.primaryBenefits, ...pkg.secondaryBenefits]
                      .slice(0, 8)
                      .map((item) => (
                        <li
                          key={item}
                          className="flex items-start gap-2 text-sm text-muted-foreground"
                        >
                          <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                          {item}
                        </li>
                      ))}
                  </ul>
                  <Link
                    href={`/booking?service=${pkg.slug}`}
                    className="mt-8 inline-flex w-full items-center justify-center rounded-2xl bg-gold py-4 font-black text-gold-foreground hover:brightness-110"
                  >
                    Book {pkg.name}
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-card px-4 py-20 md:px-8 md:py-28">
        <div className="container mx-auto max-w-6xl">
          <div className="mb-10 text-center">
            <p className="mb-4 text-sm font-extrabold uppercase tracking-[0.2em] text-gold">
              Smart Add-On — Ceramic Coating
            </p>
            <h2 className="text-4xl font-extrabold md:text-6xl">
              A Great Detail Is Step One.
              <span className="text-gradient block">This Is What Makes It Last.</span>
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
              We all live in New England — your vehicle deals with a lot. Keep
              that just-detailed look longer.
            </p>
          </div>
          <div className="grid items-center gap-8 md:grid-cols-2">
            <figure>
              <Image
                src="/images/no-coating.jpg"
                alt="Vehicle without ceramic coating showing dirt and water spots"
                width={900}
                height={700}
                className="h-72 w-full rounded-[28px] object-cover md:h-[420px]"
              />
              <figcaption className="mt-3 text-sm text-muted-foreground">
                Without coating
              </figcaption>
            </figure>
            <figure>
              <Image
                src="/images/ceramic-coated.jpg"
                alt="Car with professional ceramic coating showing hydrophobic water beading"
                width={900}
                height={700}
                className="h-72 w-full rounded-[28px] object-cover md:h-[420px]"
              />
              <figcaption className="mt-3 text-sm font-semibold text-gold">
                Completely Different Result.
              </figcaption>
            </figure>
          </div>
          <div className="mx-auto mt-10 max-w-xl rounded-[28px] border border-gold/30 bg-background p-8 text-center">
            <p className="text-base font-bold">
              Only {CERAMIC_ADDON.bundlePrice} when added to your detail{" "}
              <span className="text-sm font-normal text-muted-foreground line-through">
                (Normally {CERAMIC_ADDON.regularPrice})
              </span>
            </p>
            <p className="mt-2 text-sm text-muted-foreground">
              Limited-time pricing when bundled with a detail. Takes no
              additional booking — we handle it during your detail.
            </p>
            <ul className="mt-6 space-y-2 text-left">
              {CERAMIC_ADDON.benefits.map((item) => (
                <li key={item} className="flex items-start gap-2 text-sm">
                  <Check className="mt-0.5 h-4 w-4 text-gold" />
                  {item}
                </li>
              ))}
            </ul>
            <Link
              href="/booking?service=ceramic-1-year"
              className="mt-6 inline-flex items-center gap-2 rounded-2xl bg-gold px-8 py-4 font-black text-gold-foreground"
            >
              Add Ceramic Protection
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      <section className="px-4 py-20 md:px-8 md:py-28">
        <div className="container mx-auto">
          <div className="mb-14 text-center">
            <h2 className="text-4xl font-extrabold md:text-6xl">
              If You Want Your Vehicle To Stay Looking Like This —
            </h2>
            <p className="mt-4 text-muted-foreground">
              Most customers choose this upgrade.
            </p>
          </div>
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            {CERAMIC_WHY.map((item) => (
              <article
                key={item.title}
                className="overflow-hidden rounded-[24px] border border-border bg-card"
              >
                <Image
                  src={item.image}
                  alt={item.imageAlt}
                  width={600}
                  height={400}
                  className="h-40 w-full object-cover"
                />
                <div className="p-6">
                  <h3 className="mb-2 font-black">{item.title}</h3>
                  <p className="text-sm text-muted-foreground">{item.body}</p>
                </div>
              </article>
            ))}
          </div>
          <div className="mt-16 grid gap-8 lg:grid-cols-3">
            {CERAMIC_TIERS.map((tier) => (
              <article
                key={tier.slug}
                className={`relative flex flex-col rounded-[28px] border bg-card p-8 ${
                  tier.featured ? "border-gold/50" : "border-border"
                }`}
              >
                {tier.badge ? (
                  <div className="absolute -top-3.5 left-1/2 z-10 flex -translate-x-1/2 items-center gap-1.5 rounded-full bg-gold/90 px-5 py-1.5 text-[11px] font-black uppercase tracking-[0.15em] text-background">
                    <Sparkles className="h-3 w-3" />
                    {tier.badge}
                  </div>
                ) : null}
                <h3 className="text-2xl font-black">{tier.name}</h3>
                <p className="mt-3 text-sm text-muted-foreground">
                  {tier.description}
                </p>
                <div className="mt-6 flex gap-6">
                  <Price label="Sedan" value={tier.sedanPrice} />
                  <Price label="SUV" value={tier.suvPrice} />
                </div>
                <ul className="mt-6 flex-1 space-y-2">
                  {tier.features.map((item) => (
                    <li
                      key={item}
                      className="flex items-start gap-2 text-sm text-muted-foreground"
                    >
                      <Check className="mt-0.5 h-4 w-4 text-primary" />
                      {item}
                    </li>
                  ))}
                </ul>
                <Link
                  href={`/booking?service=${tier.slug}`}
                  className="mt-8 inline-flex items-center justify-center rounded-2xl bg-gold py-4 font-black text-gold-foreground"
                >
                  Book {tier.name}
                </Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-background px-4 py-20 md:px-8 md:py-28">
        <div className="container mx-auto max-w-5xl">
          <p className="mb-6 text-center text-sm italic tracking-wide text-muted-foreground/70">
            Not every vehicle needs a full detail — and that&apos;s okay.
          </p>
          <div className="grid items-center gap-8 md:grid-cols-2">
            <Image
              src="/images/interior-detail.jpg"
              alt="Professional interior auto detailing result showing clean seats and dashboard"
              width={800}
              height={700}
              className="h-80 w-full rounded-[28px] object-cover"
            />
            <div className="warm-shadow rounded-2xl border border-border bg-card p-7 md:p-9">
              <p className="mb-2 text-xs font-bold uppercase tracking-[0.15em] text-gold">
                Interior Only
              </p>
              <h2 className="mb-2 text-2xl font-black">Interior Detail</h2>
              <p className="mb-7 text-sm text-muted-foreground">
                Deep interior reset — cleaned, refreshed, and brought back to a
                much better condition.
              </p>
              <div className="mb-8 space-y-3">
                <div className="flex items-center justify-between rounded-xl border border-border/50 bg-secondary/60 px-5 py-4">
                  <span className="text-sm font-medium text-muted-foreground">
                    Sedan
                  </span>
                  <span className="text-3xl font-black">
                    {INTERIOR_ONLY.sedanPrice}
                  </span>
                </div>
                <div className="flex items-center justify-between rounded-xl border border-border/50 bg-secondary/60 px-5 py-4">
                  <span className="text-sm font-medium text-muted-foreground">
                    SUV / Truck / Van
                  </span>
                  <span className="text-3xl font-black">
                    {INTERIOR_ONLY.suvPrice}
                  </span>
                </div>
              </div>
              <p className="mb-4 text-xs font-bold uppercase tracking-[0.12em]">
                What&apos;s included
              </p>
              <ul className="mb-8 grid gap-3">
                {INTERIOR_ONLY.includes.map((item) => (
                  <li
                    key={item}
                    className="flex items-start gap-2.5 text-sm text-muted-foreground"
                  >
                    <Check className="mt-[3px] h-3.5 w-3.5 text-accent/70" />
                    {item}
                  </li>
                ))}
              </ul>
              <Link
                href="/booking?service=interior-only"
                className="flex items-center justify-center rounded-2xl bg-gold py-4 font-black text-gold-foreground"
              >
                Book Interior Detail
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section
        id="testimonials"
        className="relative scroll-mt-28 overflow-hidden bg-ink px-4 py-28 md:px-8 md:py-36"
      >
        <div className="hairline absolute inset-x-0 top-0 h-px" />
        <div className="container mx-auto">
          <div className="mb-16 text-center">
            <p className="mb-4 text-sm font-extrabold uppercase tracking-[0.2em] text-gold">
              Don&apos;t Take Our Word For It
            </p>
            <h2 className="mb-5 text-5xl font-extrabold md:text-7xl">
              Real People. <span className="text-gradient">Real Results.</span>
            </h2>
            <div className="mt-4 flex items-center justify-center gap-1.5">
              {Array.from({ length: 5 }).map((_, index) => (
                <Star
                  key={index}
                  className="h-7 w-7 fill-gold text-gold"
                />
              ))}
              <span className="ml-3 text-base font-bold text-white/60">
                {SITE.rating} · {SITE.reviewCount} reviews on Google
              </span>
            </div>
          </div>
          <div className="mx-auto grid max-w-6xl gap-6 md:grid-cols-2 lg:grid-cols-3">
            {testimonials.map((item) => (
              <article
                key={`${item.authorName}-${item.publishedOn}`}
                className="rounded-2xl border border-border bg-card p-7"
              >
                <div className="mb-4 flex gap-1">
                  {Array.from({ length: 5 }).map((_, index) => (
                    <Star
                      key={index}
                      className="h-4 w-4 fill-gold text-gold"
                    />
                  ))}
                </div>
                <p className="text-sm leading-relaxed text-foreground/80">
                  “{item.body}”
                </p>
                <p className="mt-5 text-sm font-bold">{item.authorName}</p>
                <p className="text-xs text-muted-foreground">{item.publishedOn}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="faq" className="scroll-mt-28 px-4 py-20 md:px-8 md:py-28">
        <div className="container mx-auto">
          <div className="mb-12 text-center">
            <p className="mb-4 text-sm font-extrabold uppercase tracking-[0.2em] text-gold">
              Questions, Answered
            </p>
            <h2 className="text-4xl font-extrabold md:text-6xl">
              Frequently Asked <span className="text-gradient">Questions</span>
            </h2>
          </div>
          <FaqList />
        </div>
      </section>

      <section className="relative overflow-hidden px-4 py-24 md:px-8">
        <Image
          src="/images/gallery-glossy.jpg"
          alt="Professional auto detailing and ceramic coating service at We Care Car Care in Framingham, MA"
          fill
          className="object-cover"
        />
        <div className="absolute inset-0 bg-background/80" />
        <div className="container relative z-10 mx-auto max-w-3xl text-center">
          <h2 className="mb-4 text-4xl font-black md:text-6xl">
            Join the {SITE.vehiclesDetailed} vehicles we&apos;ve detailed with
            care and precision.
          </h2>
          <p className="mb-8 text-muted-foreground">
            Shop, mobile, or pickup &amp; delivery across MetroWest MA.
          </p>
          <Link
            href="/booking"
            className="gold-glow inline-flex items-center gap-2 rounded-2xl bg-gold px-12 py-5 text-lg font-black text-gold-foreground"
          >
            Book Your Detail
            <ArrowRight className="h-5 w-5" />
          </Link>
        </div>
      </section>
    </main>
  );
}

function Price({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs font-bold uppercase tracking-[0.14em] text-muted-foreground">
        {label}
      </p>
      <p className="text-3xl font-black tracking-tight">{value}</p>
    </div>
  );
}
