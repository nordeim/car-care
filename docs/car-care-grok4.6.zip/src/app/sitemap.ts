import type { MetadataRoute } from "next";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";
  const routes = [
    "",
    "/about",
    "/gallery",
    "/booking",
    "/service-areas",
    "/contact",
    "/fleet-services",
    "/privacy",
  ];
  return routes.map((path, index) => ({
    url: `${base}${path}`,
    lastModified: new Date(),
    changeFrequency: path === "" || path === "/gallery" ? "weekly" : "monthly",
    priority: index === 0 ? 1 : path === "/booking" ? 0.9 : 0.8,
  }));
}
