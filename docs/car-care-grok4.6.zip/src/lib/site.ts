export const SITE = {
  name: "We Care Car Care",
  tagline: "Real detailing. Real results.",
  phoneDisplay: "(508) 290-7476",
  phoneTel: "+15082907476",
  email: "info@WeCareCarCare.com",
  street: "874 Edgell Rd",
  city: "Framingham",
  region: "MA",
  postal: "01701",
  hours: "Monday–Saturday, 8:00 AM – 6:00 PM",
  founded: "2010",
  years: "16+",
  vehiclesDetailed: "7,500+",
  rating: "5.0",
  reviewCount: 37,
  radius: "30 miles",
} as const;

export const NAV_PRIMARY = [
  { label: "About Us", href: "/about" },
  { label: "Services & Pricing", href: "/#pricing" },
  { label: "Gallery", href: "/gallery" },
] as const;

export const NAV_MORE = [
  { label: "Service Areas", href: "/service-areas" },
  { label: "Corporate & Fleet", href: "/fleet-services" },
  { label: "Testimonials", href: "/#testimonials" },
  { label: "FAQ", href: "/#faq" },
] as const;

export interface DetailPackage {
  slug: string;
  name: string;
  description: string;
  image: string;
  imageAlt: string;
  primaryBenefits: string[];
  secondaryBenefits: string[];
  sedanPrice: string;
  suvPrice: string;
  featured?: boolean;
  badge?: string;
}

export const DETAIL_PACKAGES: DetailPackage[] = [
  {
    slug: "essential-full-detail",
    name: "Essential Full Detail",
    description:
      "Full interior & exterior detail to keep your car protected & refreshed.",
    image: "/images/essential-detail.jpg",
    imageAlt: "Freshly detailed sedan with clean exterior and natural gloss",
    primaryBenefits: [
      "Interior vacuuming",
      "Trunk / cargo area vacuuming",
      "All interior hard surfaces",
    ],
    secondaryBenefits: [
      "UV protection for surfaces",
      "Carpets & seats",
      "Floor mats",
      "Exterior decontamination",
      "Exterior wash",
      "Wheel cleaning",
      "2-month spray-on paint sealant",
      "Interior & exterior glass & mirrors",
    ],
    sedanPrice: "$240",
    suvPrice: "$295",
  },
  {
    slug: "premium-full-detail",
    name: "Premium Full Detail",
    description:
      "Comprehensive full interior clean and exterior machine polish for added protection.",
    image: "/images/premium-sedan.jpg",
    imageAlt: "Premium detailed sedan with dramatic studio lighting",
    primaryBenefits: [
      "Interior vacuuming",
      "Trunk / cargo area vacuuming",
      "All interior hard surfaces",
    ],
    secondaryBenefits: [
      "UV protection for surfaces",
      "Carpets & seats",
      "Floor mats",
      "Full sanitized steam treatment",
      "Exterior decontamination",
      "Exterior clay bar treatment",
      "Exterior wash",
      "Wheel cleaning",
      "Machine polish",
      "Longer-lasting protection",
      "Higher gloss finish",
      "Scratch removal",
      "Interior & exterior glass & mirrors",
    ],
    sedanPrice: "$360",
    suvPrice: "$395",
    featured: true,
    badge: "Most Popular",
  },
];

export interface CeramicTier {
  slug: string;
  name: string;
  description: string;
  sedanPrice: string;
  suvPrice: string;
  features: string[];
  featured?: boolean;
  badge?: string;
}

export const CERAMIC_TIERS: CeramicTier[] = [
  {
    slug: "ceramic-1-year",
    name: "1-Year Protection",
    description:
      "Entry-level ceramic shield for daily drivers who want lasting gloss and easy maintenance.",
    sedanPrice: "$560",
    suvPrice: "$595",
    features: [
      "Full Premium detail before application",
      "Single-layer ceramic coating",
      "High gloss enhancement",
      "Hydrophobic finish",
      "UV protection",
      "1-year durability",
    ],
  },
  {
    slug: "ceramic-3-year",
    name: "3-Year Protection",
    description:
      "Our most popular tier — maximum gloss, serious protection, and multi-year durability.",
    sedanPrice: "$795",
    suvPrice: "$995",
    features: [
      "Full Premium detail before application",
      "Paint correction (light polish)",
      "Multi-layer ceramic coating",
      "Enhanced hydrophobic finish",
      "Deep gloss enhancement",
      "3-year durability",
    ],
    featured: true,
    badge: "Most Popular",
  },
  {
    slug: "ceramic-5-year",
    name: "5-Year Protection",
    description:
      "The ultimate in long-term paint protection for those who demand the best.",
    sedanPrice: "$995",
    suvPrice: "$1,295",
    features: [
      "Full Premium detail before application",
      "Multi-stage paint correction",
      "Premium multi-layer coating",
      "Maximum hydrophobic protection",
      "Mirror-finish gloss",
      "5-year durability",
    ],
  },
];

export const INTERIOR_ONLY = {
  sedanPrice: "$195",
  suvPrice: "$240",
  includes: [
    "Complete interior deep clean",
    "Full vacuuming including trunk",
    "All hard surfaces cleaned & conditioned",
    "Carpets & seats deep cleaned",
    "Floor mats deep cleaned",
    "UV protection applied",
    "Interior glass cleaned & polished",
  ],
} as const;

export const CERAMIC_ADDON = {
  bundlePrice: "$200",
  regularPrice: "$299",
  benefits: [
    "Stays cleaner longer (less washing)",
    "Easier to maintain day-to-day",
    "Protects against UV, sap, and contaminants",
    "Keeps that deep, glossy finish",
  ],
} as const;

export const CERAMIC_WHY = [
  {
    title: "Stays cleaner longer",
    body: "Water, road film, and grime don't stick the same way, so your vehicle stays cleaner between washes.",
    image: "/images/benefit-cleaner.jpg",
    imageAlt: "Water beading on ceramic coated dark paint",
  },
  {
    title: "Deeper, lasting gloss",
    body: "Ceramic coating helps your paint keep that deeper, glossier look long after the detail is done.",
    image: "/images/benefit-shine.jpg",
    imageAlt: "Mirror-like deep gloss on dark automotive paint",
  },
  {
    title: "Easier maintenance",
    body: "Washes are faster, drying is cleaner, and keeping the vehicle looking great takes less effort.",
    image: "/images/benefit-maintenance.jpg",
    imageAlt: "Water sheeting off ceramic coated surface",
  },
  {
    title: "Everyday protection",
    body: "Helps shield your paint from UV rays, contaminants, and everyday exposure that slowly wears finishes down.",
    image: "/images/benefit-protection.jpg",
    imageAlt: "Warm sunlight on protected car paint surface",
  },
] as const;

export interface ReviewSeed {
  authorName: string;
  body: string;
  publishedOn: string;
}

export const REVIEW_SEEDS: ReviewSeed[] = [
  {
    authorName: "Lauren B. K.",
    publishedOn: "Mar 2026",
    body: "Chris was easy to communicate with and super responsive. He made my car look like it just came off the lot!",
  },
  {
    authorName: "Jim K.",
    publishedOn: "Nov 2025",
    body: "I had my SUV detailed last week and could not be happier with the results. It was full of grass, dirt, and sand from several beach days. When Chris and team were done with it, it looked like the day I drove it off the dealer's lot 6 years ago.",
  },
  {
    authorName: "Ed L.",
    publishedOn: "Oct 2025",
    body: "Chris and staff took great care of us. 3 kids and a dog without car detailing in 10 years and Chris made the interior look brand new! Exterior wax and tire detailing made the car shine. I'll be back!",
  },
  {
    authorName: "Lisa W.",
    publishedOn: "Oct 2025",
    body: "We have used We Care Car Care for our vehicles for several years now and they are meticulous. We handed over two cars that had spent the summer on the beach — so much sand and fur. We got back cars that look brand new.",
  },
  {
    authorName: "Kimberly E.",
    publishedOn: "Aug 2025",
    body: "Chris has cleaned both of our cars several times. He's always very flexible and has been able to pick up from my work location. As we have 2 kids and often wait too long, our cars are not the cleanest, but he always does an excellent job with incredible attention to detail.",
  },
  {
    authorName: "Gayle G.",
    publishedOn: "Aug 2025",
    body: "Chris was quick to respond and easy to coordinate. He even provided pick up and return of our car. The car was covered with sap, pollen, dirt, old leaves in the crevices. Chris made it all disappear. Sparkling clean inside and out.",
  },
];

export const FAQS = [
  {
    q: "What's the difference between the Essential and Premium detail?",
    a: "The Essential Full Detail provides a thorough interior and exterior clean, ideal for regular maintenance. The Premium Full Detail goes deeper with steam sanitizing and machine polishing to address surface scratches and scuffs for a superior finish.",
  },
  {
    q: "How long will it take to detail my car?",
    a: "Detailing times vary depending on the size of your vehicle, condition and the package selected. Most full details take 3–4 hours. Most interior-only jobs take 2–3 hours. Most exterior-only jobs take 1–3 hours. We'll provide an estimated completion time when you book.",
  },
  {
    q: "How does mobile service work?",
    a: "Our custom-built mobile units allow us to bring filtered water, electricity and the tools needed to provide professional detailing services at your home or office. You book the service, and we'll take care of the rest, delivering a pristine finish right in your driveway or workplace.",
  },
  {
    q: "How does your winter pickup and drop-off service work?",
    a: "We'll pick up your car from your home or workplace, bring it to our shop for detailing, and return it looking its best. If you're not comfortable with us driving your vehicle, we can offer a ride back or cover an Uber. This service is offered at no extra cost for your convenience.",
  },
  {
    q: "How do I drop it off?",
    a: "You can drop off your vehicle at our detailing studio during your scheduled appointment time. We have a lockbox system to safely leave your vehicle the night before or in the morning before we arrive. We'll provide clear instructions if you decide to use the lockbox.",
  },
  {
    q: "What if I have pet hair or tree sap?",
    a: "Pet hair, tree sap, and other tough-to-remove contaminants usually require extra time and specialized cleaning. Please let us know when booking so we can give you an accurate estimate and plan properly. If these conditions aren't disclosed ahead of time, additional charges may apply at the appointment.",
  },
  {
    q: "How do I pay?",
    a: "We accept all major payment methods, including credit/debit cards, cash, check and Venmo. Payment is due upon completion of the service.",
  },
  {
    q: "How should I care for my car after the detail?",
    a: "To maintain the results, avoid harsh chemicals and automatic car washes. We recommend hand washing your car with gentle products designed for detailed or coated vehicles. For ceramic coating, follow our care guidelines to ensure long-lasting protection.",
  },
] as const;

export const TOWNS = [
  {
    name: "Framingham",
    zip: "01701",
    description:
      "Our home base — full climate-controlled shop with complimentary pickup & delivery.",
  },
  {
    name: "Natick",
    zip: "01760",
    description:
      "Just minutes away. We'll pick up your car and return it detailed — no hassle.",
  },
  {
    name: "Sudbury",
    zip: "01776",
    description:
      "Premium detailing and ceramic coating with free pickup & delivery to your door.",
  },
  {
    name: "Wayland",
    zip: "01778",
    description:
      "We come to you. Complimentary pickup & delivery for all detailing and coating services.",
  },
  {
    name: "Wellesley",
    zip: "02481",
    description:
      "Luxury vehicle detailing with white-glove pickup & delivery throughout Wellesley.",
  },
  {
    name: "Weston",
    zip: "02493",
    description:
      "High-end detailing and ceramic coating — we pick up and deliver right to your driveway.",
  },
  {
    name: "Marlborough",
    zip: "01752",
    description:
      "Full-service auto detailing with complimentary pickup & delivery in Marlborough.",
  },
  {
    name: "Maynard",
    zip: "01754",
    description:
      "Professional ceramic coating and detailing. We handle the drive so you don't have to.",
  },
  {
    name: "Southborough",
    zip: "01772",
    description:
      "Eco-friendly detailing with free pickup & delivery for Southborough residents.",
  },
  {
    name: "Ashland",
    zip: "01721",
    description:
      "Convenient pickup & delivery detailing and paint protection in Ashland.",
  },
  {
    name: "Dover",
    zip: "02030",
    description:
      "Premium detailing for Dover's finest vehicles — picked up and returned spotless.",
  },
  {
    name: "Sherborn",
    zip: "01770",
    description:
      "Complimentary pickup & delivery makes professional detailing effortless in Sherborn.",
  },
  {
    name: "Holliston",
    zip: "01746",
    description:
      "Professional auto detailing and ceramic coating with free pickup & delivery in Holliston.",
  },
] as const;

export const TEAM = [
  {
    role: "Founding Owner",
    name: "Patrick Horrigan",
    image: "/images/team-patrick.jpg",
    bio: "Pat is the founder of We Care Car Care and a 20-year veteran of the auto detailing and reconditioning industry. Starting his journey in high school as a body shop assistant, Patrick quickly discovered his passion for vehicles and built his first detailing business while attending college. After nearly a decade in corporate roles, including as a trainer, sales manager, and operational manager, Patrick turned his side hustle into a full-time venture. In 2010, We Care Car Care was officially launched. In 2014, Patrick assumed full ownership of the company, dedicating himself to excellence in service and innovation.",
  },
  {
    role: "Owner",
    name: "Christopher Swift",
    image: "/images/team-chris.jpg",
    bio: "Chris now leads We Care Car Care North, bringing his own expertise and passion to the company. With a fresh perspective and a dedication to upholding the We Care Car Care legacy, Chris has taken the business to new heights, maintaining the same commitment to quality, customer service, and innovation that customers have come to expect.",
  },
  {
    role: "Lead Tech",
    name: "Kyle Babbitt",
    image: "/images/team-kyle.jpg",
    bio: "At just 22, Kyle has quickly become a tremendous asset to the We Care Car Care team. With an unwavering passion for auto detailing, Kyle takes pride in his meticulous work and strives to ensure every customer is thrilled with their results. His dedication to excellence and attention to detail make him an integral part of our team.",
  },
] as const;

export const GALLERY = [
  {
    src: "/images/gallery-volvo-ext.jpg",
    alt: "Volvo XC60 exterior detail at We Care Car Care studio",
  },
  {
    src: "/images/gallery-volvo-back.jpg",
    alt: "Volvo XC60 rear seats after interior detail",
  },
  {
    src: "/images/gallery-volvo-dash.jpg",
    alt: "Volvo XC60 dashboard and interior after detailing",
  },
  {
    src: "/images/gallery-cherokee.jpg",
    alt: "Jeep Grand Cherokee exterior detail at We Care Car Care studio",
  },
  {
    src: "/images/gallery-mazda.jpg",
    alt: "White Mazda CX-5 after full exterior detail",
  },
  {
    src: "/images/gallery-gladiator.jpg",
    alt: "Black Jeep Gladiator detailed at We Care Car Care studio",
  },
  {
    src: "/images/gallery-belair-int.jpg",
    alt: "Classic 1957 Chevy Bel Air red interior after detailing",
  },
  {
    src: "/images/gallery-belair-front.jpg",
    alt: "Classic 1957 Chevy Bel Air front view with chrome detailing",
  },
  {
    src: "/images/gallery-belair-side.jpg",
    alt: "Classic 1957 Chevy Bel Air side profile showing Bel Air badge",
  },
  {
    src: "/images/gallery-volvo-dash2.jpg",
    alt: "Volvo XC60 dashboard detail with wood trim accents",
  },
  {
    src: "/images/gallery-subaru-back.jpg",
    alt: "Subaru Ascent tan leather rear seats after interior detail",
  },
  {
    src: "/images/gallery-subaru-dash.jpg",
    alt: "Subaru Ascent dashboard and center console after detailing",
  },
  {
    src: "/images/gallery-toyota.jpg",
    alt: "Toyota Highlander dashboard and JBL system after interior detail",
  },
  {
    src: "/images/gallery-acura-back.jpg",
    alt: "Acura RDX cream leather rear seats after interior detail",
  },
  {
    src: "/images/gallery-acura-dash.jpg",
    alt: "Acura RDX dashboard and center console after detailing",
  },
  {
    src: "/images/gallery-mazda-studio.jpg",
    alt: "White Mazda CX-5 side profile in We Care Car Care studio",
  },
  {
    src: "/images/gallery-tesla.jpg",
    alt: "Tesla Model Y dashboard and touchscreen after interior detail",
  },
  {
    src: "/images/gallery-bmw.jpg",
    alt: "BMW X5 glossy hood detail showing mirror-like paint correction",
  },
  {
    src: "/images/gallery-audi.jpg",
    alt: "Blue Audi A5 Cabriolet after full exterior detail",
  },
  {
    src: "/images/gallery-rr.jpg",
    alt: "Black Range Rover after full exterior detail and paint correction",
  },
  {
    src: "/images/gallery-mobile.jpg",
    alt: "We Care Car Care mobile detailing team working on-site at a customer's home",
  },
  {
    src: "/images/gallery-glossy.jpg",
    alt: "Glossy dark SUV with mirror-like finish after mobile detailing by We Care Car Care",
  },
  {
    src: "/images/gallery-driveway.jpg",
    alt: "We Care Car Care mobile detailing van on-site washing vehicles in customer driveway",
  },
  {
    src: "/images/gallery-setup.jpg",
    alt: "We Care Car Care dual vans set up for mobile detailing at customer home",
  },
] as const;

export const SERVICES = [
  { slug: "essential-full-detail", label: "Essential Full Detail" },
  { slug: "premium-full-detail", label: "Premium Full Detail" },
  { slug: "interior-only", label: "Interior Detail" },
  { slug: "ceramic-1-year", label: "1-Year Ceramic Coating" },
  { slug: "ceramic-3-year", label: "3-Year Ceramic Coating" },
  { slug: "ceramic-5-year", label: "5-Year Ceramic Coating" },
] as const;

export const VEHICLE_TYPES = ["Sedan / Coupe", "SUV / Crossover", "Truck / Van"] as const;
export const LOCATION_TYPES = [
  { value: "mobile", label: "Mobile — come to me" },
  { value: "shop", label: "Drop off at the studio" },
  { value: "pickup", label: "Pickup & delivery" },
] as const;
export const TIME_WINDOWS = [
  "8:00 AM – 10:00 AM",
  "10:00 AM – 12:00 PM",
  "12:00 PM – 2:00 PM",
  "2:00 PM – 4:00 PM",
  "4:00 PM – 6:00 PM",
] as const;

export const FLEET_CORPORATE = [
  "Executive cars",
  "Sales teams",
  "Company-owned vehicles",
  "Employee-use vehicles",
] as const;

export const FLEET_VEHICLES = [
  "Service vans & trucks",
  "School & campus vehicles",
  "Towing & transport",
  "Maintenance fleets",
] as const;

export const FLEET_EXTERIOR = [
  "Hand wash & dry",
  "Wheel and rim cleaning",
  "Paint-safe decontamination when needed",
  "Protective sealants for gloss and durability",
] as const;

export const FLEET_INTERIOR = [
  "Full vacuuming",
  "Surface cleaning and wipe-down",
  "Deep cleaning when needed (high-use vehicles)",
  "Odor removal",
] as const;

export const FLEET_ADDONS = [
  "Ceramic protection options",
  "Headlight restoration",
  "Overspray or heavy contamination removal",
] as const;

export const FLEET_REASONS = [
  {
    title: "Minimal Disruption",
    desc: "We work around your schedule or come to you — no need to pull vehicles off the road.",
  },
  {
    title: "Consistent Appearance",
    desc: "Clean vehicles reflect your brand. We help you maintain a professional look across the board.",
  },
  {
    title: "Protect Your Investment",
    desc: "Regular maintenance helps prevent long-term damage from salt, grime, and daily use.",
  },
  {
    title: "Flexible & Scalable",
    desc: "From a few vehicles to larger fleets, we tailor a simple plan that works.",
  },
] as const;

export const FLEET_CLIENTS = [
  "Bose",
  "Dana Hall School",
  "Master Chimney Sweep",
  "MA Restoration",
  "Henry's Towing",
  "Apple Orchard School",
] as const;

export const FLEET_STEPS = [
  {
    num: "01",
    title: "Reach Out",
    desc: "Tell us about your vehicles and what you're looking for.",
  },
  {
    num: "02",
    title: "We Put Together a Plan",
    desc: "Clear, straightforward pricing based on your needs.",
  },
  {
    num: "03",
    title: "We Handle the Work",
    desc: "On-site or at our shop — whatever makes the most sense.",
  },
] as const;

export function serviceLabel(slug: string): string {
  const match = SERVICES.find((item) => item.slug === slug);
  return match?.label ?? slug;
}
