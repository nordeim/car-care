import { count } from "drizzle-orm";
import { db } from "@/db";
import { reviews } from "@/db/schema";
import { REVIEW_SEEDS } from "@/lib/site";

const globalForSeed = globalThis as typeof globalThis & {
  __wcccSeedPromise?: Promise<void>;
};

async function seedReviews() {
  const [row] = await db.select({ total: count() }).from(reviews);
  if ((row?.total ?? 0) > 0) return;
  await db.insert(reviews).values(
    REVIEW_SEEDS.map((item) => ({
      authorName: item.authorName,
      body: item.body,
      publishedOn: item.publishedOn,
      rating: "5",
    })),
  );
}

export function ensureSeeded(): Promise<void> {
  if (!globalForSeed.__wcccSeedPromise) {
    globalForSeed.__wcccSeedPromise = seedReviews().catch((error: unknown) => {
      globalForSeed.__wcccSeedPromise = undefined;
      throw error;
    });
  }
  return globalForSeed.__wcccSeedPromise;
}
