import Image from "next/image";
import Link from "next/link";
import { Leaf } from "lucide-react";
import { SITE } from "@/lib/site";

const FOOTER_LINKS = [
  { label: "Service Areas", href: "/service-areas" },
  { label: "Testimonials", href: "/#testimonials" },
  { label: "FAQ", href: "/#faq" },
  { label: "Privacy", href: "/privacy" },
] as const;

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-card px-4 py-12">
      <div className="container mx-auto">
        <div className="mb-6 flex flex-col items-center justify-between gap-6 md:flex-row">
          <Link href="/" className="flex items-center gap-3">
            <Image
              src="/brand/logo.png"
              alt="We Care Car Care"
              width={160}
              height={64}
              className="h-12 w-auto"
            />
          </Link>
          <nav className="flex flex-wrap items-center justify-center gap-4" aria-label="Footer">
            {FOOTER_LINKS.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
              >
                {item.label}
              </Link>
            ))}
          </nav>
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} {SITE.name}
          </p>
        </div>
        <div className="mx-auto max-w-2xl text-center">
          <p className="mb-3 text-sm leading-relaxed text-muted-foreground">
            Based in Framingham, MA,{" "}
            <span className="font-semibold text-foreground">{SITE.name}</span> proudly
            serves the MetroWest Boston community with high-quality auto detailing,
            ceramic coating, and paint protection. We bring our mobile service
            directly to you in Framingham, Natick, Sudbury, Wayland, Wellesley,
            Weston, Marlborough, Maynard, Southborough, Ashland, Dover, Sherborn,
            and Holliston.
          </p>
          <p className="mb-1 flex items-center justify-center gap-2 text-sm text-muted-foreground">
            <Leaf className="h-4 w-4 text-primary" />
            <span>Eco-Friendly Auto Detailing · Since {SITE.founded}</span>
          </p>
          <p className="text-xs text-muted-foreground">
            {SITE.street}, {SITE.city}, {SITE.region} {SITE.postal} · {SITE.phoneDisplay}{" "}
            · {SITE.email}
          </p>
        </div>
      </div>
    </footer>
  );
}
