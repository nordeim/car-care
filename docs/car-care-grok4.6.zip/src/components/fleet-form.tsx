"use client";

import { useState } from "react";

const SIZES = ["1–5", "6–15", "16–40", "40+"] as const;
const TYPES = [
  "Executive cars",
  "Service vans / trucks",
  "Mixed fleet",
  "Campus / school vehicles",
] as const;
const PREFS = ["On-site", "Shop", "Either"] as const;

export function FleetForm() {
  const [companyName, setCompanyName] = useState("");
  const [contactName, setContactName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [fleetSize, setFleetSize] = useState<string>(SIZES[0]);
  const [vehicleTypes, setVehicleTypes] = useState<string>(TYPES[2]);
  const [servicePreference, setServicePreference] = useState<string>(PREFS[2]);
  const [notes, setNotes] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const response = await fetch("/api/fleet", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          companyName,
          contactName,
          email,
          phone,
          fleetSize,
          vehicleTypes,
          servicePreference,
          notes,
        }),
      });
      const payload: unknown = await response.json();
      if (!response.ok) {
        const text =
          typeof payload === "object" &&
          payload !== null &&
          "error" in payload &&
          typeof (payload as { error: unknown }).error === "string"
            ? (payload as { error: string }).error
            : "Could not send your inquiry.";
        setError(text);
        return;
      }
      setDone(true);
    } catch {
      setError("Network error. Please call (508) 290-7476.");
    } finally {
      setSubmitting(false);
    }
  }

  if (done) {
    return (
      <div className="rounded-2xl border border-gold/40 bg-card p-8 text-center">
        <p className="mb-2 text-sm font-black uppercase tracking-[0.2em] text-gold">
          Fleet request received
        </p>
        <h2 className="text-2xl font-black">We&apos;ll put a plan together.</h2>
        <p className="mt-3 text-muted-foreground">
          A coordinator will follow up with straightforward pricing based on vehicle
          count and location.
        </p>
      </div>
    );
  }

  return (
    <form id="fleet-quote" onSubmit={onSubmit} className="rounded-2xl border border-border bg-card p-6 md:p-10">
      <div className="grid gap-4 md:grid-cols-2">
        <label className="text-sm font-semibold">
          Company
          <input
            required
            value={companyName}
            onChange={(event) => setCompanyName(event.target.value)}
            className="mt-2 w-full rounded-xl border border-border bg-secondary px-4 py-3"
          />
        </label>
        <label className="text-sm font-semibold">
          Contact name
          <input
            required
            value={contactName}
            onChange={(event) => setContactName(event.target.value)}
            className="mt-2 w-full rounded-xl border border-border bg-secondary px-4 py-3"
          />
        </label>
      </div>
      <div className="mt-4 grid gap-4 md:grid-cols-2">
        <label className="text-sm font-semibold">
          Email
          <input
            required
            type="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            className="mt-2 w-full rounded-xl border border-border bg-secondary px-4 py-3"
          />
        </label>
        <label className="text-sm font-semibold">
          Phone
          <input
            required
            type="tel"
            value={phone}
            onChange={(event) => setPhone(event.target.value)}
            className="mt-2 w-full rounded-xl border border-border bg-secondary px-4 py-3"
          />
        </label>
      </div>
      <div className="mt-4 grid gap-4 md:grid-cols-3">
        <label className="text-sm font-semibold">
          Fleet size
          <select
            value={fleetSize}
            onChange={(event) => setFleetSize(event.target.value)}
            className="mt-2 w-full rounded-xl border border-border bg-secondary px-4 py-3"
          >
            {SIZES.map((item) => (
              <option key={item}>{item}</option>
            ))}
          </select>
        </label>
        <label className="text-sm font-semibold">
          Vehicle mix
          <select
            value={vehicleTypes}
            onChange={(event) => setVehicleTypes(event.target.value)}
            className="mt-2 w-full rounded-xl border border-border bg-secondary px-4 py-3"
          >
            {TYPES.map((item) => (
              <option key={item}>{item}</option>
            ))}
          </select>
        </label>
        <label className="text-sm font-semibold">
          Service
          <select
            value={servicePreference}
            onChange={(event) => setServicePreference(event.target.value)}
            className="mt-2 w-full rounded-xl border border-border bg-secondary px-4 py-3"
          >
            {PREFS.map((item) => (
              <option key={item}>{item}</option>
            ))}
          </select>
        </label>
      </div>
      <label className="mt-4 block text-sm font-semibold">
        Notes
        <textarea
          rows={4}
          value={notes}
          onChange={(event) => setNotes(event.target.value)}
          className="mt-2 w-full rounded-xl border border-border bg-secondary px-4 py-3"
        />
      </label>
      {error ? (
        <p className="mt-4 rounded-xl border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm" role="alert">
          {error}
        </p>
      ) : null}
      <button
        type="submit"
        disabled={submitting}
        className="mt-6 rounded-xl bg-gold px-8 py-3 font-black text-gold-foreground disabled:opacity-60"
      >
        {submitting ? "Sending…" : "Request a fleet plan"}
      </button>
    </form>
  );
}
