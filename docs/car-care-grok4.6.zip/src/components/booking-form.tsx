"use client";

import { useMemo, useState } from "react";
import {
  LOCATION_TYPES,
  SERVICES,
  TIME_WINDOWS,
  VEHICLE_TYPES,
} from "@/lib/site";

interface FormState {
  fullName: string;
  email: string;
  phone: string;
  vehicleType: string;
  vehicleYear: string;
  vehicleMake: string;
  vehicleModel: string;
  serviceSlug: string;
  locationType: string;
  address: string;
  zipCode: string;
  preferredDate: string;
  preferredTime: string;
  notes: string;
}

const EMPTY: FormState = {
  fullName: "",
  email: "",
  phone: "",
  vehicleType: VEHICLE_TYPES[0],
  vehicleYear: "",
  vehicleMake: "",
  vehicleModel: "",
  serviceSlug: "premium-full-detail",
  locationType: "pickup",
  address: "",
  zipCode: "",
  preferredDate: "",
  preferredTime: TIME_WINDOWS[1],
  notes: "",
};

export function BookingForm({
  defaultService,
}: {
  defaultService?: string;
}) {
  const [step, setStep] = useState(1);
  const [form, setForm] = useState<FormState>({
    ...EMPTY,
    serviceSlug: defaultService ?? EMPTY.serviceSlug,
  });
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [confirmation, setConfirmation] = useState<string | null>(null);

  const minDate = useMemo(() => {
    const date = new Date();
    date.setDate(date.getDate() + 1);
    return date.toISOString().slice(0, 10);
  }, []);

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  function validateStep(current: number): string | null {
    if (current === 1 && !form.serviceSlug) return "Choose a service.";
    if (current === 2) {
      if (!form.vehicleType) return "Select a vehicle type.";
      if (!form.locationType) return "Select how we should service the vehicle.";
      if (form.locationType !== "shop") {
        if (!form.zipCode.trim()) return "ZIP code is required for mobile and pickup service.";
        if (!/^\d{5}$/.test(form.zipCode.trim())) return "Enter a 5-digit ZIP code.";
      }
    }
    if (current === 3) {
      if (form.fullName.trim().length < 2) return "Please enter your name.";
      if (!form.email.includes("@")) return "Enter a valid email.";
      if (form.phone.replace(/\D/g, "").length < 10) return "Enter a 10-digit phone number.";
      if (!form.preferredDate) return "Choose a preferred date.";
    }
    return null;
  }

  function next() {
    const issue = validateStep(step);
    if (issue) {
      setError(issue);
      return;
    }
    setError(null);
    setStep((value) => Math.min(3, value + 1));
  }

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    const issue = validateStep(3);
    if (issue) {
      setError(issue);
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      const response = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const payload: unknown = await response.json();
      if (!response.ok) {
        const message =
          typeof payload === "object" &&
          payload !== null &&
          "error" in payload &&
          typeof (payload as { error: unknown }).error === "string"
            ? (payload as { error: string }).error
            : "We could not save your request. Please call us.";
        setError(message);
        return;
      }
      const id =
        typeof payload === "object" &&
        payload !== null &&
        "id" in payload &&
        typeof (payload as { id: unknown }).id === "string"
          ? (payload as { id: string }).id
          : "received";
      setConfirmation(id.slice(0, 8).toUpperCase());
    } catch {
      setError("Network error. Please try again or call (508) 290-7476.");
    } finally {
      setSubmitting(false);
    }
  }

  if (confirmation) {
    return (
      <div className="rounded-2xl border border-primary/30 bg-card p-8 text-center">
        <p className="mb-2 text-sm font-black uppercase tracking-[0.2em] text-gold">
          Request received
        </p>
        <h2 className="mb-3 text-3xl font-black">You&apos;re on the calendar list.</h2>
        <p className="mx-auto mb-6 max-w-md text-muted-foreground">
          Confirmation {confirmation}. We&apos;ll text or email within one business day
          to lock the time. Same-day questions? Call (508) 290-7476.
        </p>
        <button
          type="button"
          className="rounded-xl bg-gold px-6 py-3 font-black text-gold-foreground"
          onClick={() => {
            setConfirmation(null);
            setForm(EMPTY);
            setStep(1);
          }}
        >
          Book another vehicle
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="rounded-2xl border border-border bg-card p-6 md:p-10">
      <ol className="mb-8 grid grid-cols-3 gap-2 text-center text-xs font-bold uppercase tracking-[0.14em] text-muted-foreground">
        {["Service", "Vehicle", "Schedule"].map((label, index) => (
          <li
            key={label}
            className={`rounded-full px-2 py-2 ${
              step === index + 1 ? "bg-gold text-gold-foreground" : "bg-secondary"
            }`}
          >
            {index + 1}. {label}
          </li>
        ))}
      </ol>

      {step === 1 ? (
        <fieldset className="space-y-3">
          <legend className="mb-4 text-2xl font-black">Choose your service</legend>
          {SERVICES.map((service) => (
            <label
              key={service.slug}
              className={`flex cursor-pointer items-center justify-between rounded-xl border px-4 py-4 ${
                form.serviceSlug === service.slug
                  ? "border-gold bg-gold/10"
                  : "border-border bg-secondary/40"
              }`}
            >
              <span className="font-semibold">{service.label}</span>
              <input
                type="radio"
                name="serviceSlug"
                value={service.slug}
                checked={form.serviceSlug === service.slug}
                onChange={() => update("serviceSlug", service.slug)}
                className="accent-gold"
              />
            </label>
          ))}
        </fieldset>
      ) : null}

      {step === 2 ? (
        <div className="grid gap-5">
          <h2 className="text-2xl font-black">Vehicle & location</h2>
          <label className="block text-sm font-semibold">
            Vehicle type
            <select
              className="mt-2 w-full rounded-xl border border-border bg-secondary px-4 py-3"
              value={form.vehicleType}
              onChange={(event) => update("vehicleType", event.target.value)}
            >
              {VEHICLE_TYPES.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
          </label>
          <div className="grid gap-4 md:grid-cols-3">
            <Field
              label="Year"
              value={form.vehicleYear}
              onChange={(value) => update("vehicleYear", value)}
              placeholder="2022"
            />
            <Field
              label="Make"
              value={form.vehicleMake}
              onChange={(value) => update("vehicleMake", value)}
              placeholder="BMW"
            />
            <Field
              label="Model"
              value={form.vehicleModel}
              onChange={(value) => update("vehicleModel", value)}
              placeholder="X5"
            />
          </div>
          <fieldset className="space-y-3">
            <legend className="mb-2 text-sm font-semibold">How should we service it?</legend>
            {LOCATION_TYPES.map((item) => (
              <label
                key={item.value}
                className={`flex cursor-pointer items-center justify-between rounded-xl border px-4 py-3 ${
                  form.locationType === item.value
                    ? "border-primary bg-primary/10"
                    : "border-border"
                }`}
              >
                <span>{item.label}</span>
                <input
                  type="radio"
                  name="locationType"
                  checked={form.locationType === item.value}
                  onChange={() => update("locationType", item.value)}
                />
              </label>
            ))}
          </fieldset>
          {form.locationType !== "shop" ? (
            <div className="grid gap-4 md:grid-cols-3">
              <div className="md:col-span-2">
                <Field
                  label="Street address"
                  value={form.address}
                  onChange={(value) => update("address", value)}
                  placeholder="123 Main St"
                />
              </div>
              <Field
                label="ZIP"
                value={form.zipCode}
                onChange={(value) => update("zipCode", value)}
                placeholder="01701"
              />
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">
              Studio drop-off: 874 Edgell Rd, Framingham, MA 01701. Lockbox available
              overnight.
            </p>
          )}
        </div>
      ) : null}

      {step === 3 ? (
        <div className="grid gap-5">
          <h2 className="text-2xl font-black">Your details</h2>
          <Field
            label="Full name"
            value={form.fullName}
            onChange={(value) => update("fullName", value)}
            required
          />
          <div className="grid gap-4 md:grid-cols-2">
            <Field
              label="Email"
              type="email"
              value={form.email}
              onChange={(value) => update("email", value)}
              required
            />
            <Field
              label="Phone"
              type="tel"
              value={form.phone}
              onChange={(value) => update("phone", value)}
              required
            />
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <label className="block text-sm font-semibold">
              Preferred date
              <input
                type="date"
                min={minDate}
                required
                value={form.preferredDate}
                onChange={(event) => update("preferredDate", event.target.value)}
                className="mt-2 w-full rounded-xl border border-border bg-secondary px-4 py-3"
              />
            </label>
            <label className="block text-sm font-semibold">
              Time window
              <select
                className="mt-2 w-full rounded-xl border border-border bg-secondary px-4 py-3"
                value={form.preferredTime}
                onChange={(event) => update("preferredTime", event.target.value)}
              >
                {TIME_WINDOWS.map((item) => (
                  <option key={item}>{item}</option>
                ))}
              </select>
            </label>
          </div>
          <label className="block text-sm font-semibold">
            Notes (pet hair, tree sap, ceramic interest)
            <textarea
              rows={4}
              value={form.notes}
              onChange={(event) => update("notes", event.target.value)}
              className="mt-2 w-full rounded-xl border border-border bg-secondary px-4 py-3"
            />
          </label>
        </div>
      ) : null}

      {error ? (
        <p className="mt-5 rounded-xl border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm" role="alert">
          {error}
        </p>
      ) : null}

      <div className="mt-8 flex flex-wrap gap-3">
        {step > 1 ? (
          <button
            type="button"
            onClick={() => {
              setError(null);
              setStep((value) => value - 1);
            }}
            className="rounded-xl border border-border px-6 py-3 font-bold"
          >
            Back
          </button>
        ) : null}
        {step < 3 ? (
          <button
            type="button"
            onClick={next}
            className="rounded-xl bg-gold px-8 py-3 font-black text-gold-foreground"
          >
            Continue
          </button>
        ) : (
          <button
            type="submit"
            disabled={submitting}
            className="rounded-xl bg-gold px-8 py-3 font-black text-gold-foreground disabled:opacity-60"
          >
            {submitting ? "Sending…" : "Request appointment"}
          </button>
        )}
      </div>
      <p className="mt-4 text-xs text-muted-foreground">
        We never sell your information. Payment is due when the detail is complete.
      </p>
    </form>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  placeholder,
  required,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
  placeholder?: string;
  required?: boolean;
}) {
  const id = label.toLowerCase().replace(/\s+/g, "-");
  return (
    <label className="block text-sm font-semibold" htmlFor={id}>
      {label}
      <input
        id={id}
        type={type}
        required={required}
        placeholder={placeholder}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="mt-2 w-full rounded-xl border border-border bg-secondary px-4 py-3"
      />
    </label>
  );
}
