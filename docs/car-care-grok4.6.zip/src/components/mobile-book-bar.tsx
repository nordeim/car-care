"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Phone } from "lucide-react";
import { SITE } from "@/lib/site";

export function MobileBookBar() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 600);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  if (!visible) return null;

  return (
    <div className="fixed inset-x-0 bottom-0 z-50 md:hidden">
      <div className="flex items-center gap-2 border-t border-white/[0.06] bg-background/80 px-4 py-2.5 backdrop-blur-xl">
        <a
          href={`tel:${SITE.phoneTel}`}
          className="inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-xl border border-border font-bold"
        >
          <Phone className="h-4 w-4 text-gold" />
          Call
        </a>
        <Link
          href="/booking"
          className="inline-flex h-12 flex-[2] items-center justify-center rounded-xl bg-gold font-black text-gold-foreground"
        >
          Book Your Detail
        </Link>
      </div>
    </div>
  );
}
