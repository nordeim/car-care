"use client";

import { useState } from "react";

const TOPICS = [
  "Pricing & availability",
  "Ceramic coating",
  "Mobile / pickup questions",
  "Something else",
] as const;

export function ContactForm() {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [topic, setTopic] = useState<string>(TOPICS[0]);
  const [message, setMessage] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fullName, email, phone, topic, message }),
      });
      const payload: unknown = await response.json();
      if (!response.ok) {
        const text =
          typeof payload === "object" &&
          payload !== null &&
          "error" in payload &&
          typeof (payload as { error: unknown }).error === "string"
            ? (payload as { error: string }).error
            : "Could not send your message.";
        setError(text);
        return;
      }
      setDone(true);
    } catch {
      setError("Network error. Please call (508) 290-7476.");
    } finally {
      setSubmitting(false);
    }
  }

  if (done) {
    return (
      <div className="rounded-2xl border border-primary/30 bg-card p-8 text-center">
        <p className="mb-2 text-sm font-black uppercase tracking-[0.2em] text-gold">
          Message received
        </p>
        <h2 className="text-2xl font-black">We&apos;ll follow up shortly.</h2>
        <p className="mt-3 text-muted-foreground">
          Expect a reply with pricing and availability. For same-day questions, call
          or text (508) 290-7476.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="rounded-2xl border border-border bg-card p-6 md:p-10">
      <div className="grid gap-4 md:grid-cols-2">
        <label className="text-sm font-semibold">
          Name
          <input
            required
            value={fullName}
            onChange={(event) => setFullName(event.target.value)}
            className="mt-2 w-full rounded-xl border border-border bg-secondary px-4 py-3"
          />
        </label>
        <label className="text-sm font-semibold">
          Email
          <input
            required
            type="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            className="mt-2 w-full rounded-xl border border-border bg-secondary px-4 py-3"
          />
        </label>
      </div>
      <div className="mt-4 grid gap-4 md:grid-cols-2">
        <label className="text-sm font-semibold">
          Phone
          <input
            type="tel"
            value={phone}
            onChange={(event) => setPhone(event.target.value)}
            className="mt-2 w-full rounded-xl border border-border bg-secondary px-4 py-3"
          />
        </label>
        <label className="text-sm font-semibold">
          Topic
          <select
            value={topic}
            onChange={(event) => setTopic(event.target.value)}
            className="mt-2 w-full rounded-xl border border-border bg-secondary px-4 py-3"
          >
            {TOPICS.map((item) => (
              <option key={item}>{item}</option>
            ))}
          </select>
        </label>
      </div>
      <label className="mt-4 block text-sm font-semibold">
        How can we help?
        <textarea
          required
          rows={5}
          value={message}
          onChange={(event) => setMessage(event.target.value)}
          className="mt-2 w-full rounded-xl border border-border bg-secondary px-4 py-3"
        />
      </label>
      {error ? (
        <p className="mt-4 rounded-xl border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm" role="alert">
          {error}
        </p>
      ) : null}
      <button
        type="submit"
        disabled={submitting}
        className="mt-6 rounded-xl bg-gold px-8 py-3 font-black text-gold-foreground disabled:opacity-60"
      >
        {submitting ? "Sending…" : "Send message"}
      </button>
    </form>
  );
}
