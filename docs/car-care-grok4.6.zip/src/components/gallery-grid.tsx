"use client";

import { useEffect, useState } from "react";
import { X } from "lucide-react";
import { GALLERY } from "@/lib/site";

export function GalleryGrid() {
  const [active, setActive] = useState<number | null>(null);

  useEffect(() => {
    if (active === null) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setActive(null);
      if (event.key === "ArrowRight") {
        setActive((current) =>
          current === null ? 0 : (current + 1) % GALLERY.length,
        );
      }
      if (event.key === "ArrowLeft") {
        setActive((current) =>
          current === null
            ? 0
            : (current - 1 + GALLERY.length) % GALLERY.length,
        );
      }
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [active]);

  return (
    <>
      <div className="container mx-auto grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
        {GALLERY.map((item, index) => (
          <button
            key={item.src}
            type="button"
            aria-label={`View larger image: ${item.alt}`}
            className="group aspect-square overflow-hidden rounded-xl border border-border focus:outline-none focus:ring-2 focus:ring-primary"
            onClick={() => setActive(index)}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={item.src}
              alt={item.alt}
              className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
              loading="lazy"
            />
          </button>
        ))}
      </div>
      {active !== null ? (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-black/90 p-4"
          onClick={() => setActive(null)}
          role="dialog"
          aria-modal="true"
          aria-label={GALLERY[active].alt}
        >
          <button
            type="button"
            aria-label="Close gallery"
            className="absolute right-4 top-4 rounded-full border border-white/20 p-2 text-white"
            onClick={() => setActive(null)}
          >
            <X className="h-5 w-5" />
          </button>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={GALLERY[active].src}
            alt={GALLERY[active].alt}
            className="max-h-[90vh] max-w-full rounded-lg object-contain"
            onClick={(event) => event.stopPropagation()}
          />
        </div>
      ) : null}
    </>
  );
}
