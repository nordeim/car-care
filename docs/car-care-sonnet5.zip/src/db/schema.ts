import { pgTable, text, timestamp, uuid, varchar } from "drizzle-orm/pg-core";

/**
 * Booking / quote-request submissions from the public site's contact and
 * "Book Now" forms. Content (services, pricing, FAQ) lives in src/data/*
 * as the source of truth — this table only stores transactional leads.
 */
export const bookings = pgTable("bookings", {
  id: uuid("id").primaryKey().defaultRandom(),
  fullName: varchar("full_name", { length: 120 }).notNull(),
  email: varchar("email", { length: 200 }).notNull(),
  phone: varchar("phone", { length: 40 }).notNull(),
  zipCode: varchar("zip_code", { length: 10 }).notNull(),
  vehicleType: varchar("vehicle_type", { length: 40 }).notNull(),
  serviceInterest: varchar("service_interest", { length: 40 }).notNull(),
  preferredDate: varchar("preferred_date", { length: 40 }),
  message: text("message"),
  status: varchar("status", { length: 20 }).notNull().default("new"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Booking = typeof bookings.$inferSelect;
export type NewBooking = typeof bookings.$inferInsert;
