import Link from "next/link";
import { Clock, Mail, MapPin, Phone } from "lucide-react";
import { Container } from "@/components/ui";
import { site } from "@/data/site";

function FacebookIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...props}>
      <path d="M13.5 21v-7.5H16l.5-3.5h-3V7.8c0-1 .3-1.7 1.7-1.7H16.5V3.1C16.2 3 15.2 3 14.1 3c-2.3 0-3.9 1.4-3.9 4v2.9H7.7v3.5h2.5V21h3.3Z" />
    </svg>
  );
}

function InstagramIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true" {...props}>
      <rect x="3.5" y="3.5" width="17" height="17" rx="4.5" />
      <circle cx="12" cy="12" r="3.6" />
      <circle cx="17" cy="7" r="0.9" fill="currentColor" stroke="none" />
    </svg>
  );
}

const serviceLinks = [
  { href: "/services#essential-detail", label: "Essential Detail" },
  { href: "/services#plus-detail", label: "Plus Detail" },
  { href: "/services#premium-detail", label: "Premium Detail" },
  { href: "/ceramic-coating", label: "Ceramic Coating" },
  { href: "/services#mobile-detailing", label: "Mobile Detailing" },
];

const companyLinks = [
  { href: "/about", label: "About Us" },
  { href: "/gallery", label: "Gallery" },
  { href: "/faq", label: "FAQ" },
  { href: "/contact", label: "Contact & Booking" },
];

export function SiteFooter() {
  return (
    <footer className="border-t border-border/70 bg-ink text-white/80">
      <Container className="grid gap-10 py-14 md:grid-cols-4">
        <div className="md:col-span-1">
          <p className="font-display text-xl font-bold text-white">We Care Car Care</p>
          <p className="mt-3 text-sm leading-relaxed text-white/60">{site.description}</p>
          <div className="mt-5 flex items-center gap-3">
            <a
              href={site.socials.facebook}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="We Care Car Care on Facebook"
              className="flex size-9 items-center justify-center rounded-md border border-white/15 text-white/70 transition-colors hover:border-accent hover:text-accent"
            >
              <FacebookIcon className="size-4" aria-hidden="true" />
            </a>
            <a
              href={site.socials.instagram}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="We Care Car Care on Instagram"
              className="flex size-9 items-center justify-center rounded-md border border-white/15 text-white/70 transition-colors hover:border-accent hover:text-accent"
            >
              <InstagramIcon className="size-4" aria-hidden="true" />
            </a>
          </div>
        </div>

        <FooterColumn title="Services" links={serviceLinks} />
        <FooterColumn title="Company" links={companyLinks} />

        <div>
          <h4 className="text-sm font-semibold uppercase tracking-[0.1em] text-white/50">Visit / Contact</h4>
          <ul className="mt-4 space-y-3 text-sm text-white/70">
            <li className="flex items-start gap-2.5">
              <MapPin className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden="true" />
              <span>
                {site.address.street}, {site.address.unit}
                <br />
                {site.address.city}, {site.address.region} {site.address.postalCode}
              </span>
            </li>
            <li className="flex items-center gap-2.5">
              <Phone className="size-4 shrink-0 text-accent" aria-hidden="true" />
              <a href={`tel:${site.phone}`} className="hover:text-white">
                {site.phoneDisplay}
              </a>
            </li>
            <li className="flex items-center gap-2.5">
              <Mail className="size-4 shrink-0 text-accent" aria-hidden="true" />
              <a href={`mailto:${site.email}`} className="hover:text-white break-all">
                {site.email}
              </a>
            </li>
            <li className="flex items-start gap-2.5">
              <Clock className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden="true" />
              <span>
                {site.hours.map((h) => (
                  <span key={h.days} className="block">
                    {h.days}: {h.time}
                  </span>
                ))}
              </span>
            </li>
          </ul>
        </div>
      </Container>

      <div className="border-t border-white/10">
        <Container className="flex flex-col items-center justify-between gap-3 py-6 text-xs text-white/50 sm:flex-row">
          <p>
            &copy; {new Date().getFullYear()} {site.name}. All rights reserved.
          </p>
          <p>Serving Framingham &amp; MetroWest Massachusetts within a {site.serviceRadiusMiles}-mile radius.</p>
        </Container>
      </div>
    </footer>
  );
}

function FooterColumn({ title, links }: { title: string; links: { href: string; label: string }[] }) {
  return (
    <div>
      <h4 className="text-sm font-semibold uppercase tracking-[0.1em] text-white/50">{title}</h4>
      <ul className="mt-4 space-y-2.5 text-sm">
        {links.map((link) => (
          <li key={link.href}>
            <Link href={link.href} className="text-white/70 transition-colors hover:text-white">
              {link.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
