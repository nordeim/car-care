import { Droplets, Gem, Shield, Sparkles, Truck, Wind, type LucideIcon } from "lucide-react";
import type { ServiceSummary } from "@/data/services";

const ICONS: Record<ServiceSummary["icon"], LucideIcon> = {
  droplets: Droplets,
  sparkles: Sparkles,
  wind: Wind,
  gem: Gem,
  shield: Shield,
  truck: Truck,
};

export function ServiceIcon({ icon, className }: { icon: ServiceSummary["icon"]; className?: string }) {
  const Icon = ICONS[icon];
  return <Icon className={className} aria-hidden="true" />;
}
