"use client";

import { CheckCircle2, Loader2, TriangleAlert } from "lucide-react";
import { useId, useState, type FormEvent } from "react";
import { Button } from "@/components/ui";
import { serviceInterestValues, vehicleTypeValues } from "@/lib/validation";

const SERVICE_LABELS: Record<(typeof serviceInterestValues)[number], string> = {
  essential_detail: "Essential Detail",
  plus_detail: "Plus Detail",
  premium_detail: "Premium Detail",
  ceramic_coating: "Ceramic / Graphene Coating",
  mobile_detailing: "Mobile Detailing",
  not_sure: "Not sure yet — advise me",
};

const VEHICLE_LABELS: Record<(typeof vehicleTypeValues)[number], string> = {
  sedan_coupe: "Sedan / Coupe",
  crossover_suv: "Crossover / Small SUV",
  truck_suv_van: "3-Row SUV / Van / Truck",
  other: "Other",
};

type SubmitState = { status: "idle" | "submitting" | "success" | "error"; message?: string };

export function BookingForm() {
  const [state, setState] = useState<SubmitState>({ status: "idle" });
  const formId = useId();

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setState({ status: "submitting" });

    const form = event.currentTarget;
    const data = new FormData(form);
    const payload = {
      fullName: String(data.get("fullName") ?? ""),
      email: String(data.get("email") ?? ""),
      phone: String(data.get("phone") ?? ""),
      zipCode: String(data.get("zipCode") ?? ""),
      vehicleType: String(data.get("vehicleType") ?? ""),
      serviceInterest: String(data.get("serviceInterest") ?? ""),
      preferredDate: String(data.get("preferredDate") ?? ""),
      message: String(data.get("message") ?? ""),
      companyWebsite: String(data.get("companyWebsite") ?? ""),
    };

    try {
      const res = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const json = (await res.json()) as { ok: boolean; error?: string };

      if (!res.ok || !json.ok) {
        setState({ status: "error", message: json.error ?? "Something went wrong. Please call us instead." });
        return;
      }

      form.reset();
      setState({ status: "success" });
    } catch {
      setState({ status: "error", message: "Network error — please try again or call us directly." });
    }
  }

  if (state.status === "success") {
    return (
      <div
        role="status"
        className="flex flex-col items-center gap-3 rounded-xl border border-success/30 bg-success/5 px-6 py-12 text-center"
      >
        <CheckCircle2 className="size-10 text-success" aria-hidden="true" />
        <p className="font-display text-xl font-semibold text-foreground">Request received!</p>
        <p className="max-w-sm text-sm text-muted-foreground">
          Thanks for reaching out — we&apos;ll text or call you within one business day to confirm your appointment.
        </p>
        <Button variant="outline" onClick={() => setState({ status: "idle" })} className="mt-2">
          Submit another request
        </Button>
      </div>
    );
  }

  const isSubmitting = state.status === "submitting";

  return (
    <form onSubmit={handleSubmit} noValidate className="space-y-5">
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Full name" htmlFor={`${formId}-fullName`} required>
          <input
            id={`${formId}-fullName`}
            name="fullName"
            type="text"
            required
            minLength={2}
            maxLength={120}
            autoComplete="name"
            className={inputClasses}
            placeholder="Jane Doe"
          />
        </Field>
        <Field label="Phone" htmlFor={`${formId}-phone`} required>
          <input
            id={`${formId}-phone`}
            name="phone"
            type="tel"
            required
            autoComplete="tel"
            className={inputClasses}
            placeholder="(508) 555-0100"
          />
        </Field>
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Email" htmlFor={`${formId}-email`} required>
          <input
            id={`${formId}-email`}
            name="email"
            type="email"
            required
            autoComplete="email"
            className={inputClasses}
            placeholder="jane@example.com"
          />
        </Field>
        <Field label="ZIP code" htmlFor={`${formId}-zip`} required>
          <input
            id={`${formId}-zip`}
            name="zipCode"
            type="text"
            inputMode="numeric"
            pattern="\d{5}"
            required
            maxLength={5}
            autoComplete="postal-code"
            className={inputClasses}
            placeholder="01701"
          />
        </Field>
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Vehicle type" htmlFor={`${formId}-vehicle`} required>
          <select id={`${formId}-vehicle`} name="vehicleType" required defaultValue="" className={inputClasses}>
            <option value="" disabled>
              Select vehicle type
            </option>
            {vehicleTypeValues.map((value) => (
              <option key={value} value={value}>
                {VEHICLE_LABELS[value]}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Service interested in" htmlFor={`${formId}-service`} required>
          <select id={`${formId}-service`} name="serviceInterest" required defaultValue="" className={inputClasses}>
            <option value="" disabled>
              Select a service
            </option>
            {serviceInterestValues.map((value) => (
              <option key={value} value={value}>
                {SERVICE_LABELS[value]}
              </option>
            ))}
          </select>
        </Field>
      </div>

      <Field label="Preferred date (optional)" htmlFor={`${formId}-date`}>
        <input id={`${formId}-date`} name="preferredDate" type="text" className={inputClasses} placeholder="e.g. next Saturday morning" />
      </Field>

      <Field label="Anything we should know? (optional)" htmlFor={`${formId}-message`}>
        <textarea
          id={`${formId}-message`}
          name="message"
          rows={4}
          maxLength={2000}
          className={inputClasses}
          placeholder="Pet hair, tree sap, scratches — tell us about your vehicle."
        />
      </Field>

      {/* Honeypot — hidden from real users, visible to naive bots. */}
      <div className="hidden" aria-hidden="true">
        <label htmlFor={`${formId}-company`}>Company website</label>
        <input id={`${formId}-company`} name="companyWebsite" type="text" tabIndex={-1} autoComplete="off" />
      </div>

      {state.status === "error" ? (
        <p role="alert" className="flex items-start gap-2 rounded-md border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          <TriangleAlert className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
          {state.message}
        </p>
      ) : null}

      <Button type="submit" variant="accent" size="lg" disabled={isSubmitting} className="w-full sm:w-auto">
        {isSubmitting ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : null}
        {isSubmitting ? "Sending request…" : "Request my appointment"}
      </Button>
      <p className="text-xs text-muted-foreground">
        By submitting, you agree to be contacted by We Care Car Care about your request. We never share your info.
      </p>
    </form>
  );
}

const inputClasses =
  "block w-full rounded-md border border-border bg-white px-3.5 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/70 focus:border-primary focus:outline-none focus:ring-2 focus:ring-ring/40";

function Field({
  label,
  htmlFor,
  required,
  children,
}: {
  label: string;
  htmlFor: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label htmlFor={htmlFor} className="mb-1.5 block text-sm font-medium text-foreground">
        {label}
        {required ? <span className="text-primary"> *</span> : null}
      </label>
      {children}
    </div>
  );
}
