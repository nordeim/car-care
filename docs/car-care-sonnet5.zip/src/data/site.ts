/**
 * Canonical business facts, mirrored from We Care Car Care's published
 * structured data (schema.org/AutoWash + FAQPage) so every page — content,
 * metadata, and JSON-LD — stays in sync with one source.
 */
export const site = {
  name: "We Care Car Care",
  shortName: "We Care",
  tagline: "Auto Detailing & Ceramic Coating",
  description:
    "Top-rated auto detailing, ceramic coating, and paint protection in Framingham and MetroWest Massachusetts. Mobile, shop, and pickup/delivery options — 16+ years of five-star care.",
  url: "https://wecarecarcare.example.com",
  phone: "+15082907476",
  phoneDisplay: "(508) 290-7476",
  email: "Chris@WeCareCarCare.com",
  foundingYear: 2010,
  yearsExperience: new Date().getFullYear() - 2010,
  rating: 5.0,
  reviewCount: 37,
  address: {
    street: "874 Edgell Rd",
    unit: "Unit 3",
    city: "Framingham",
    region: "MA",
    postalCode: "01701",
    country: "US",
  },
  geo: { latitude: 42.3186, longitude: -71.4167 },
  hours: [
    { days: "Monday – Saturday", time: "8:00 AM – 6:00 PM" },
    { days: "Sunday", time: "Closed" },
  ],
  serviceRadiusMiles: 30,
  serviceAreas: [
    "Framingham",
    "Natick",
    "Sudbury",
    "Wayland",
    "Wellesley",
    "Marlboro",
    "Weston",
    "Maynard",
    "Southborough",
    "Ashland",
    "Dover",
    "Sherborn",
    "Holliston",
  ],
  socials: {
    facebook: "https://www.facebook.com/wecarecarcare",
    instagram: "https://www.instagram.com/wecarecarcare",
  },
} as const;
