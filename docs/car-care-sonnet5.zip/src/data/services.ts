export interface ServiceSummary {
  slug: string;
  name: string;
  tagline: string;
  description: string;
  bullets: string[];
  icon: "sparkles" | "droplets" | "shield" | "gem" | "truck" | "wind";
  durationHint: string;
}

export const services: ServiceSummary[] = [
  {
    slug: "base-exterior",
    name: "Base Exterior Detail",
    tagline: "Wash, decontaminate, protect",
    description:
      "A thorough exterior refresh that strips winter grime and road film without stripping your paint's protection.",
    bullets: [
      "Foam pre-soak hand wash, wheels & tires scrubbed",
      "Surface iron & fallout decontamination",
      "Clay bar paint cleaning removes bonded contaminants",
      "Tree sap, bug, and road tar spot removal",
      "Natural-finish trim dressing",
      "6–8 month ceramic spray sealant",
    ],
    icon: "droplets",
    durationHint: "1–3 hours",
  },
  {
    slug: "essential-detail",
    name: "Essential Detail",
    tagline: "Full interior + exterior, done right",
    description:
      "Our most-booked package — a complete interior and exterior clean that's ideal for regular maintenance and keeping resale value high.",
    bullets: [
      "Everything in the Base Exterior Detail",
      "Full interior vacuum: seats, carpets, trunk, floor mats",
      "All hard surfaces cleaned & UV-protected",
      "Interior & exterior glass, mirrors cleaned streak-free",
      "Door jambs and console detailing",
    ],
    icon: "sparkles",
    durationHint: "2–3 hours",
  },
  {
    slug: "plus-detail",
    name: "Plus Detail",
    tagline: "Deep steam clean + machine polish",
    description:
      "Everything in Essential, elevated: steam sanitizing pulls out set-in grime and odor, while a machine polish knocks out light scratches and swirls.",
    bullets: [
      "Steam-cleaned upholstery, carpets & headliner",
      "Machine polish removes light scratches & swirl marks",
      "Odor neutralizing treatment",
      "Leather conditioning where applicable",
      "Engine bay wipe-down on request",
    ],
    icon: "wind",
    durationHint: "3–4 hours",
  },
  {
    slug: "premium-detail",
    name: "Premium Detail",
    tagline: "Full correction & restoration",
    description:
      "Complete vehicle restoration: single-stage paint correction removes up to 100% of defects, then locks in the results with a ceramic or graphene coating.",
    bullets: [
      "Single-stage machine polish, 70–100% defect removal",
      "Black plastic trim restored & coated",
      "Headlight clarification polish + protective coating",
      "1-year or 5-year warrantied ceramic/graphene coating",
      "Full interior deep clean included",
    ],
    icon: "gem",
    durationHint: "4–8 hours",
  },
  {
    slug: "ceramic-coating",
    name: "Ceramic & Graphene Coating",
    tagline: "Hydrophobic gloss that lasts years, not weeks",
    description:
      "Professional-grade nano-ceramic and graphene coatings bond to your clear coat, delivering a deep, self-cleaning gloss backed by real warranties.",
    bullets: [
      "1-year and 5-year warrantied options",
      "5+ year coating backed by a transferable Transparency warranty",
      "Extreme hydrophobic beading, easier washes",
      "UV, oxidation & chemical-stain resistance",
      "Glassparency-certified windshield & glass coatings available",
    ],
    icon: "shield",
    durationHint: "Same-day to 2 days",
  },
  {
    slug: "mobile-detailing",
    name: "Mobile Detailing",
    tagline: "We bring the studio to you",
    description:
      "Our custom-built mobile units carry filtered water, power, and every tool we use in the shop — book once, and we handle the rest at your home or office.",
    bullets: [
      "Self-contained water & power — no hose or outlet needed",
      "Available across Framingham & MetroWest, 30-mile radius",
      "Same premium products & process as our studio",
      "Winter pickup & drop-off available at no extra cost",
    ],
    icon: "truck",
    durationHint: "On your schedule",
  },
];

export function getServiceBySlug(slug: string): ServiceSummary | undefined {
  return services.find((s) => s.slug === slug);
}
