export interface TieredPrice {
  sedanCoupe: number;
  crossoverSuv: number;
  truckSuvVan: number;
}

export interface PackageTier {
  name: string;
  description: string;
  price: TieredPrice;
  featured?: boolean;
  includes: string[];
}

/**
 * Studio detailing packages. Tier 1 = coupes/sedans, Tier 2 = crossovers &
 * small SUVs, Tier 3 = three-row SUVs, minivans & trucks. All prices are
 * "starting at" and may vary with vehicle condition — matches the pricing
 * disclaimer used on-site.
 */
export const detailingPackages: PackageTier[] = [
  {
    name: "Base Exterior Detail",
    description: "Exterior-only refresh — ideal between full details.",
    price: { sedanCoupe: 100, crossoverSuv: 120, truckSuvVan: 140 },
    includes: [
      "Foam hand wash & wheel/tire cleaning",
      "Clay bar decontamination",
      "Tree sap, bug & tar removal",
      "6–8 month ceramic sealant",
    ],
  },
  {
    name: "Essential Detail",
    description: "Full interior + exterior clean for regular maintenance.",
    price: { sedanCoupe: 220, crossoverSuv: 240, truckSuvVan: 260 },
    featured: true,
    includes: [
      "Everything in Base Exterior Detail",
      "Full interior vacuum & wipe-down",
      "Interior & exterior glass cleaned",
      "UV surface protection",
    ],
  },
  {
    name: "Plus Detail",
    description: "Steam-sanitized interior with machine-polished exterior.",
    price: { sedanCoupe: 360, crossoverSuv: 375, truckSuvVan: 395 },
    includes: [
      "Everything in Essential Detail",
      "Steam cleaning for carpets, seats & headliner",
      "Machine polish removes light scratches",
      "Odor neutralizing treatment",
    ],
  },
];

export const paintCorrectionPackages: PackageTier[] = [
  {
    name: "1-Year Ceramic / Graphene Package",
    description: "Single-stage paint correction topped with a 1+ year coating.",
    price: { sedanCoupe: 600, crossoverSuv: 700, truckSuvVan: 850 },
    includes: [
      "Everything in Base Exterior Detail",
      "Single-stage machine polish, 70–100% defect removal",
      "1+ year ceramic or graphene coating",
      "Black trim restored & coated + headlight clarification",
    ],
  },
  {
    name: "5-Year Warrantied Ceramic Package",
    description: "Our most protective package, backed by a transferable warranty.",
    price: { sedanCoupe: 999, crossoverSuv: 1250, truckSuvVan: 1400 },
    featured: true,
    includes: [
      "Everything in the 1-Year Ceramic/Graphene Package",
      "5+ year Ceramic Coating",
      "Transferable warranty backed by Transparency",
      "Priority scheduling for annual maintenance",
    ],
  },
];

export const upgradeAddOns = [
  { name: "Single-Step Paint Correction upgrade", price: { sedanCoupe: 120, crossoverSuv: 140, truckSuvVan: 160 } },
  { name: "1-Year Lite Ceramic/Graphene upgrade", price: { sedanCoupe: 25, crossoverSuv: 30, truckSuvVan: 40 } },
];

export const vehicleTierLabels: Record<keyof TieredPrice, string> = {
  sedanCoupe: "Sedan / Coupe",
  crossoverSuv: "Crossover / Small SUV",
  truckSuvVan: "3-Row SUV / Van / Truck",
};
