export interface Testimonial {
  name: string;
  location: string;
  rating: number;
  quote: string;
  vehicle: string;
}

/**
 * Representative five-star feedback in the voice of a long-running MetroWest
 * detailing studio. Illustrative copy — not scraped review text.
 */
export const testimonials: Testimonial[] = [
  {
    name: "Melissa R.",
    location: "Framingham, MA",
    rating: 5,
    quote:
      "Chris and the team have detailed our cars for years. The ceramic coating still beads water like it's brand new two winters later. Worth every penny.",
    vehicle: "Audi Q5",
  },
  {
    name: "David K.",
    location: "Natick, MA",
    rating: 5,
    quote:
      "Mobile detailing saved me — they set up in my driveway with their own water and power and my truck looked better than the day I bought it.",
    vehicle: "Ford F-150",
  },
  {
    name: "Priya S.",
    location: "Wellesley, MA",
    rating: 5,
    quote:
      "Had pet hair embedded everywhere from two golden retrievers. The Plus Detail's steam clean got it all out. Genuinely didn't think it was possible.",
    vehicle: "Honda CR-V",
  },
  {
    name: "Tom B.",
    location: "Sudbury, MA",
    rating: 5,
    quote:
      "Winter pickup and drop-off is such an easy way to keep the car protected all season. Lockbox drop-off is simple and the communication is great.",
    vehicle: "Subaru Outback",
  },
];
