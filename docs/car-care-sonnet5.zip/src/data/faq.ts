export interface FaqItem {
  question: string;
  answer: string;
}

/** Mirrors the FAQPage structured data published on the live site. */
export const faqs: FaqItem[] = [
  {
    question: "What's the difference between the Base and Plus package?",
    answer:
      "The Base package is designed to provide a thorough clean of your car's interior and exterior, ideal for regular maintenance. The Plus package provides a deeper interior clean using steam to sanitize, plus machine polishing to address scratches and scuffs that will come out.",
  },
  {
    question: "How long will it take to detail my car?",
    answer:
      "Detailing times vary depending on the size of your vehicle, its condition, and the package selected. Most full details take 3–4 hours. Most interior-only jobs take 2–3 hours. Most exterior-only jobs take 1–3 hours. We'll provide an estimated completion time when you book.",
  },
  {
    question: "How does mobile service work?",
    answer:
      "Our custom-built mobile units allow us to bring filtered water, electricity, and the tools needed to provide professional detailing services at your home or office. You book the service, and we'll take care of the rest.",
  },
  {
    question: "How does your winter pickup and drop-off service work?",
    answer:
      "We'll pick up your car from your home or workplace, bring it to our shop for detailing, and return it looking its best. If you're not comfortable with us driving your vehicle, we can offer a ride back or cover an Uber. This service is offered at no extra cost.",
  },
  {
    question: "How do I drop it off?",
    answer:
      "You can drop off your vehicle at our detailing studio during your scheduled appointment time. We have a lockbox system so you can safely leave your vehicle the night before or in the morning before we arrive.",
  },
  {
    question: "What if I have pet hair or tree sap?",
    answer:
      "Pet hair, tree sap, and other tough-to-remove contaminants may require additional time and specialized cleaning products. Let us know when booking, and we'll evaluate your vehicle to provide an accurate estimate.",
  },
  {
    question: "How do I pay?",
    answer:
      "We accept all major payment methods, including credit/debit cards, cash, check, and Venmo. Payment is due upon completion of the service.",
  },
  {
    question: "How should I care for my car after the detail?",
    answer:
      "To maintain the results, avoid harsh chemicals and automatic car washes. We recommend hand washing your car with gentle products designed for detailed or coated vehicles. For ceramic coating, follow our care guidelines to ensure long-lasting protection.",
  },
];
