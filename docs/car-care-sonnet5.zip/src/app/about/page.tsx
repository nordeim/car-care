import type { Metadata } from "next";
import Image from "next/image";
import { Award, HeartHandshake, Leaf, MapPin } from "lucide-react";
import { Badge, ButtonLink, Container, SectionHeading } from "@/components/ui";
import { site } from "@/data/site";

export const metadata: Metadata = {
  title: "About Us",
  description: `Meet the team behind ${site.name} — a family-run auto detailing studio serving Framingham and MetroWest Massachusetts since ${site.foundingYear}.`,
};

const values = [
  {
    icon: Award,
    title: "Craft over shortcuts",
    description: "Every vehicle gets the same meticulous process, whether it's a daily driver or a weekend project car.",
  },
  {
    icon: Leaf,
    title: "Eco-conscious products",
    description: "Filtered, low-runoff water systems and pH-balanced, eco-friendly chemicals protect your car and the neighborhood.",
  },
  {
    icon: HeartHandshake,
    title: "Honest recommendations",
    description: "We'll tell you when a lighter package is the right call — we're building relationships, not one-time tickets.",
  },
];

export default function AboutPage() {
  return (
    <>
      <header className="border-b border-border bg-card py-16 sm:py-20">
        <Container className="grid gap-10 lg:grid-cols-2 lg:items-center">
          <div>
            <Badge className="mb-4">About Us</Badge>
            <h1 className="text-balance font-display text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
              Family-run, detail-obsessed, since {site.foundingYear}.
            </h1>
            <p className="mt-5 max-w-lg text-lg leading-relaxed text-muted-foreground">
              We Care Car Care started as a one-man mobile operation and grew into Framingham&apos;s go-to detailing
              studio through word of mouth alone — {site.reviewCount}+ five-star reviews and counting.
            </p>
            <div className="mt-7 flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <MapPin className="size-4 text-primary" aria-hidden="true" />
              {site.address.street}, {site.address.city}, {site.address.region}
            </div>
          </div>
          <div className="relative aspect-4/5 overflow-hidden rounded-2xl">
            <Image
              src="/images/about-team.jpg"
              alt="Owner of We Care Car Care standing in front of the detailing studio"
              fill
              priority
              className="object-cover"
              sizes="(min-width: 1024px) 40vw, 100vw"
            />
          </div>
        </Container>
      </header>

      <section className="py-20 sm:py-24">
        <Container>
          <SectionHeading
            eyebrow="Our story"
            title="Built on referrals, not advertising"
            description={`What started with a single mobile detailing unit in ${site.foundingYear} has grown into a full studio at ${site.address.street} — but the mission hasn't changed: treat every car like it's our own.`}
          />
          <div className="mt-12 grid gap-6 sm:grid-cols-3">
            {values.map((v) => (
              <div key={v.title} className="rounded-xl border border-border bg-card p-6">
                <div className="flex size-11 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <v.icon className="size-5" aria-hidden="true" />
                </div>
                <h3 className="mt-4 font-display text-base font-semibold text-foreground">{v.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{v.description}</p>
              </div>
            ))}
          </div>
        </Container>
      </section>

      <section className="bg-card py-20 sm:py-24">
        <Container>
          <SectionHeading eyebrow="Where we work" title="Studio, mobile, or drop-off — your choice" align="center" className="mx-auto" />
          <p className="mx-auto mt-6 max-w-2xl text-center text-muted-foreground">
            Our appointment-only detailing studio sits at {site.address.street}, {site.address.unit},{" "}
            {site.address.city}, {site.address.region}, with a secure two-way key drop for 24/7 vehicle pickup and
            drop-off. Our mobile units serve the rest of MetroWest within a {site.serviceRadiusMiles}-mile radius.
          </p>
          <div className="mx-auto mt-8 flex max-w-2xl flex-wrap justify-center gap-2">
            {site.serviceAreas.map((area) => (
              <span key={area} className="rounded-full border border-border bg-background px-3.5 py-1.5 text-sm text-muted-foreground">
                {area}
              </span>
            ))}
          </div>
          <div className="mt-10 flex justify-center">
            <ButtonLink href="/contact" variant="primary" size="lg">
              Book with us
            </ButtonLink>
          </div>
        </Container>
      </section>
    </>
  );
}
