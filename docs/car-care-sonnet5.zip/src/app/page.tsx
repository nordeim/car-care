import Image from "next/image";
import Link from "next/link";
import { ArrowRight, MapPin, ShieldCheck, Sparkles, Star, Timer } from "lucide-react";
import { db } from "@/db";
import { sql } from "drizzle-orm";
import { Badge, ButtonLink, Card, Container, SectionHeading } from "@/components/ui";
import { ServiceIcon } from "@/components/service-icon";
import { services } from "@/data/services";
import { detailingPackages, vehicleTierLabels } from "@/data/packages";
import { testimonials } from "@/data/testimonials";
import { site } from "@/data/site";
import { cn } from "@/lib/utils";

export const dynamic = "force-dynamic";

const stats = [
  { label: "Years in business", value: `${site.yearsExperience}+` },
  { label: "Average rating", value: site.rating.toFixed(1) },
  { label: "Five-star reviews", value: `${site.reviewCount}+` },
  { label: "Mile service radius", value: `${site.serviceRadiusMiles}` },
];

const whyUs = [
  {
    icon: ShieldCheck,
    title: "Warrantied protection",
    description: "1-year and 5-year ceramic coatings backed by real, transferable warranties — not marketing fluff.",
  },
  {
    icon: Timer,
    title: "Same-day scheduling",
    description: "Studio drop-off, mobile visits, or our winter pickup-and-delivery — book around your schedule, not ours.",
  },
  {
    icon: Sparkles,
    title: "16+ years of craft",
    description: "Family-run since 2010. We've detailed thousands of MetroWest vehicles and it shows in the finish.",
  },
];

export default async function HomePage() {
  // Confirms the DB connection is healthy on every render of the primary
  // landing page — cheap no-op query, mirrors the platform health check.
  await db.execute(sql`select 1`);

  return (
    <>
      <HeroSection />
      <TrustStrip />
      <ServicesSection />
      <PricingPreview />
      <WhyUsSection />
      <TestimonialsSection />
      <FinalCta />
    </>
  );
}

function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-ink">
      <div className="absolute inset-0">
        <Image
          src="/images/hero-detailing.jpg"
          alt="Detailer hand-polishing the hood of a glossy sedan in a bright studio bay"
          fill
          priority
          className="object-cover opacity-70"
          sizes="100vw"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/85 to-ink/30" />
        <div className="absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-ink to-transparent" />
      </div>

      <Container className="relative flex min-h-[640px] flex-col justify-center py-24 sm:min-h-[700px]">
        <p className="animate-fade-up mb-5 text-sm font-semibold uppercase tracking-[0.18em] text-accent">
          Framingham &amp; MetroWest Massachusetts
        </p>
        <h1 className="animate-fade-up max-w-2xl text-balance font-display text-4xl font-bold leading-[1.05] tracking-tight text-white sm:text-6xl">
          Auto detailing &amp; ceramic coating your car actually deserves.
        </h1>
        <p className="animate-fade-up mt-6 max-w-xl text-lg leading-relaxed text-white/75">
          {site.yearsExperience}+ years of five-star detailing, paint correction, and warrantied ceramic coatings —
          in our studio, mobile at your door, or with free winter pickup &amp; delivery.
        </p>
        <div className="animate-fade-up mt-9 flex flex-col gap-3 sm:flex-row">
          <ButtonLink href="/contact" variant="accent" size="lg">
            Book my appointment <ArrowRight className="size-4" aria-hidden="true" />
          </ButtonLink>
          <ButtonLink href="/services" variant="onDark" size="lg">
            See services &amp; pricing
          </ButtonLink>
        </div>

        <div className="animate-fade-up mt-12 flex flex-wrap items-center gap-x-8 gap-y-4">
          <div className="flex items-center gap-1.5 text-white">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star key={i} className="size-4 fill-accent text-accent" aria-hidden="true" />
            ))}
            <span className="ml-1 text-sm font-semibold">{site.rating.toFixed(1)} rating &middot; {site.reviewCount} reviews</span>
          </div>
          <div className="flex items-center gap-1.5 text-sm font-medium text-white/70">
            <MapPin className="size-4 text-accent" aria-hidden="true" />
            874 Edgell Rd, Framingham, MA
          </div>
        </div>
      </Container>
    </section>
  );
}

function TrustStrip() {
  return (
    <section className="border-b border-border bg-card">
      <Container className="grid grid-cols-2 gap-6 py-10 sm:grid-cols-4">
        {stats.map((stat) => (
          <div key={stat.label} className="text-center sm:text-left">
            <p className="font-display text-3xl font-bold text-foreground sm:text-4xl">{stat.value}</p>
            <p className="mt-1 text-sm text-muted-foreground">{stat.label}</p>
          </div>
        ))}
      </Container>
    </section>
  );
}

function ServicesSection() {
  return (
    <section className="py-20 sm:py-28">
      <Container>
        <SectionHeading
          eyebrow="What we do"
          title="Detailing packages built around how you actually use your car"
          description="From a quick exterior refresh to full paint correction and multi-year ceramic protection, every package starts with the same meticulous process."
        />
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((service) => (
            <Card key={service.slug} id={service.slug} className="flex flex-col p-6">
              <div className="flex size-11 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <ServiceIcon icon={service.icon} className="size-5" />
              </div>
              <h3 className="mt-5 font-display text-lg font-semibold text-foreground">{service.name}</h3>
              <p className="mt-1 text-sm font-medium text-primary">{service.tagline}</p>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{service.description}</p>
              <div className="mt-5 flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                <Timer className="size-3.5" aria-hidden="true" />
                {service.durationHint}
              </div>
              <Link
                href={`/services#${service.slug}`}
                className="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-primary hover:text-primary-600"
              >
                View details <ArrowRight className="size-3.5" aria-hidden="true" />
              </Link>
            </Card>
          ))}
        </div>
      </Container>
    </section>
  );
}

function PricingPreview() {
  return (
    <section className="bg-ink py-20 text-white sm:py-28">
      <Container>
        <SectionHeading
          eyebrow="Transparent pricing"
          title="Studio package pricing, by vehicle size"
          description="Prices shown are starting rates and may vary with vehicle condition — we'll always confirm before we start."
          className="text-white"
          titleClassName="text-white"
        />
        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          {detailingPackages.map((pkg) => (
            <div
              key={pkg.name}
              className={cn(
                "flex flex-col rounded-xl border p-7",
                pkg.featured ? "border-accent bg-white/[0.06] shadow-lift" : "border-white/10 bg-white/[0.03]",
              )}
            >
              {pkg.featured ? <Badge className="mb-4 w-fit border-accent/40 bg-accent/10 text-accent">Most popular</Badge> : null}
              <h3 className="font-display text-xl font-semibold">{pkg.name}</h3>
              <p className="mt-2 text-sm text-white/60">{pkg.description}</p>
              <p className="mt-6 font-display text-3xl font-bold">
                ${pkg.price.sedanCoupe}
                <span className="text-base font-medium text-white/50"> starting</span>
              </p>
              <ul className="mt-3 space-y-1 text-xs text-white/50">
                {(Object.keys(vehicleTierLabels) as Array<keyof typeof vehicleTierLabels>).map((tier) => (
                  <li key={tier}>
                    {vehicleTierLabels[tier]}: ${pkg.price[tier]}
                  </li>
                ))}
              </ul>
              <ul className="mt-6 flex-1 space-y-2.5 text-sm text-white/80">
                {pkg.includes.map((line) => (
                  <li key={line} className="flex items-start gap-2">
                    <ShieldCheck className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden="true" />
                    {line}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-10 text-center">
          <ButtonLink href="/services" variant="accent" size="lg">
            View full pricing &amp; paint correction packages
          </ButtonLink>
        </div>
      </Container>
    </section>
  );
}

function WhyUsSection() {
  return (
    <section className="py-20 sm:py-28">
      <Container className="grid gap-14 lg:grid-cols-2 lg:items-center">
        <div className="relative aspect-4/5 overflow-hidden rounded-2xl">
          <Image
            src="/images/ceramic-coating-hero.jpg"
            alt="Macro shot of water beading off a freshly ceramic-coated car hood"
            fill
            className="object-cover"
            sizes="(min-width: 1024px) 40vw, 100vw"
          />
        </div>
        <div>
          <SectionHeading
            eyebrow="Why MetroWest trusts us"
            title="Real products. Real warranties. Real craftsmanship."
            description="We're not a drive-through wash — every vehicle is hand-corrected and protected by a technician who's been doing this since 2010."
          />
          <div className="mt-10 space-y-7">
            {whyUs.map((item) => (
              <div key={item.title} className="flex gap-4">
                <div className="flex size-11 shrink-0 items-center justify-center rounded-lg bg-accent/15 text-accent-600">
                  <item.icon className="size-5" aria-hidden="true" />
                </div>
                <div>
                  <h3 className="font-display text-base font-semibold text-foreground">{item.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Container>
    </section>
  );
}

function TestimonialsSection() {
  return (
    <section className="bg-card py-20 sm:py-28">
      <Container>
        <SectionHeading
          align="center"
          eyebrow="Customer stories"
          title="Trusted by drivers across Framingham & MetroWest"
          className="mx-auto"
        />
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {testimonials.map((t) => (
            <figure key={t.name} className="flex flex-col rounded-xl border border-border bg-background p-6">
              <div className="flex gap-0.5 text-accent">
                {Array.from({ length: t.rating }).map((_, i) => (
                  <Star key={i} className="size-3.5 fill-accent" aria-hidden="true" />
                ))}
              </div>
              <blockquote className="mt-4 flex-1 text-sm leading-relaxed text-foreground">&ldquo;{t.quote}&rdquo;</blockquote>
              <figcaption className="mt-5 border-t border-border pt-4 text-sm">
                <p className="font-semibold text-foreground">{t.name}</p>
                <p className="text-xs text-muted-foreground">
                  {t.location} &middot; {t.vehicle}
                </p>
              </figcaption>
            </figure>
          ))}
        </div>
      </Container>
    </section>
  );
}

function FinalCta() {
  return (
    <section className="py-20 sm:py-24">
      <Container>
        <div className="flex flex-col items-center gap-6 rounded-2xl bg-primary px-8 py-14 text-center text-white sm:px-16">
          <h2 className="max-w-xl text-balance font-display text-3xl font-bold sm:text-4xl">
            Ready to see your car look brand new again?
          </h2>
          <p className="max-w-lg text-white/85">
            Book online in under a minute, or call us directly — we typically confirm same-day.
          </p>
          <div className="flex flex-col gap-3 sm:flex-row">
            <ButtonLink href="/contact" variant="accent" size="lg">
              Book Now
            </ButtonLink>
            <ButtonLink href={`tel:${site.phone}`} variant="onDark" size="lg">
              Call {site.phoneDisplay}
            </ButtonLink>
          </div>
        </div>
      </Container>
    </section>
  );
}
