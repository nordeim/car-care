import { NextRequest } from "next/server";
import { db } from "@/db";
import { bookings } from "@/db/schema";
import { bookingSchema } from "@/lib/validation";
import { getClientIp, rateLimit } from "@/lib/rate-limit";

export const dynamic = "force-dynamic";

const RATE_LIMIT_MAX = 8;
const RATE_LIMIT_WINDOW_MS = 10 * 60 * 1000;

export async function POST(request: NextRequest) {
  const ip = getClientIp(request.headers);
  const { allowed } = rateLimit(`booking:${ip}`, RATE_LIMIT_MAX, RATE_LIMIT_WINDOW_MS);

  if (!allowed) {
    return Response.json(
      { ok: false, error: "Too many requests. Please try again in a few minutes or call us directly." },
      { status: 429 },
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid request body." }, { status: 400 });
  }

  const parsed = bookingSchema.safeParse(body);
  if (!parsed.success) {
    const firstIssue = parsed.error.issues[0];
    return Response.json(
      { ok: false, error: firstIssue?.message ?? "Please check the form and try again." },
      { status: 400 },
    );
  }

  // Honeypot tripped — silently report success to avoid tipping off bots.
  if (parsed.data.companyWebsite) {
    return Response.json({ ok: true });
  }

  try {
    const [row] = await db
      .insert(bookings)
      .values({
        fullName: parsed.data.fullName,
        email: parsed.data.email,
        phone: parsed.data.phone,
        zipCode: parsed.data.zipCode,
        vehicleType: parsed.data.vehicleType,
        serviceInterest: parsed.data.serviceInterest,
        preferredDate: parsed.data.preferredDate || null,
        message: parsed.data.message || null,
      })
      .returning({ id: bookings.id });

    if (!row) {
      return Response.json({ ok: false, error: "Could not save your request. Please try again." }, { status: 500 });
    }

    return Response.json({ ok: true, id: row.id });
  } catch (error) {
    console.error("[api/bookings] insert failed", { message: error instanceof Error ? error.message : error });
    return Response.json(
      { ok: false, error: "We couldn't save your request right now. Please call us instead." },
      { status: 500 },
    );
  }
}
