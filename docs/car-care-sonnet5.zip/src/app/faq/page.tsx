import type { Metadata } from "next";
import { Badge, ButtonLink, Container, SectionHeading } from "@/components/ui";
import { FaqAccordion } from "@/components/faq-accordion";
import { faqs } from "@/data/faq";

export const metadata: Metadata = {
  title: "Frequently Asked Questions",
  description: "Answers to common questions about scheduling, mobile detailing, payment, and vehicle care from We Care Car Care.",
};

export default function FaqPage() {
  return (
    <>
      <header className="border-b border-border bg-card py-16 sm:py-20">
        <Container>
          <Badge className="mb-4">FAQ</Badge>
          <h1 className="max-w-2xl text-balance font-display text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
            Questions? We&apos;ve got answers.
          </h1>
        </Container>
      </header>

      <section className="py-16 sm:py-20">
        <Container className="max-w-3xl">
          <FaqAccordion items={faqs} />

          <div className="mt-12 flex flex-col items-center gap-4 rounded-2xl border border-border bg-card px-8 py-10 text-center">
            <SectionHeading title="Still have a question?" align="center" className="mx-auto" />
            <ButtonLink href="/contact" variant="primary" size="lg">
              Ask us directly
            </ButtonLink>
          </div>
        </Container>
      </section>
    </>
  );
}
