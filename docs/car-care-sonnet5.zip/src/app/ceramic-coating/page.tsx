import type { Metadata } from "next";
import Image from "next/image";
import { CheckCircle2, Droplet, ShieldCheck, Sparkle, Sun } from "lucide-react";
import { Badge, ButtonLink, Card, Container, SectionHeading } from "@/components/ui";
import { paintCorrectionPackages, vehicleTierLabels } from "@/data/packages";

export const metadata: Metadata = {
  title: "Ceramic Coating & Paint Protection",
  description:
    "Professional-grade ceramic and graphene coatings in Framingham, MA — hydrophobic gloss, UV & chemical resistance, and warrantied options up to 5+ years.",
};

const benefits = [
  {
    icon: Droplet,
    title: "Hydrophobic beading",
    description: "Water, road grime, and salt sheet off instead of bonding to your paint — washes take a fraction of the time.",
  },
  {
    icon: Sun,
    title: "UV & oxidation resistance",
    description: "Ceramic coatings block UV rays that fade and oxidize factory clear coat, keeping color deeper for longer.",
  },
  {
    icon: Sparkle,
    title: "Show-quality gloss",
    description: "A properly corrected and coated surface reflects light with a wet, glass-like depth that wax can't match.",
  },
  {
    icon: ShieldCheck,
    title: "Warrantied protection",
    description: "Our 5-year package is backed by a transferable Transparency warranty — protection that follows the car, not just the owner.",
  },
];

const process = [
  { step: "01", title: "Wash & decontaminate", description: "Foam pre-soak, iron fallout removal, and a full clay bar treatment strip every bonded contaminant." },
  { step: "02", title: "Single-stage correction", description: "Machine polishing removes 70–100% of swirls, scratches, and oxidation depending on paint condition." },
  { step: "03", title: "Coating application", description: "Ceramic or graphene coating is hand-applied in controlled conditions and cured before pickup." },
  { step: "04", title: "Final inspection", description: "We walk the finish under raking light with you before your vehicle leaves the studio." },
];

export default function CeramicCoatingPage() {
  return (
    <>
      <header className="relative overflow-hidden bg-ink">
        <div className="absolute inset-0">
          <Image
            src="/images/ceramic-coating-hero.jpg"
            alt="Macro shot of water beading on a ceramic-coated black car hood"
            fill
            priority
            className="object-cover opacity-60"
            sizes="100vw"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/80 to-ink/20" />
        </div>
        <Container className="relative py-24 sm:py-28">
          <Badge className="mb-5 border-accent/40 bg-accent/10 text-accent">Ceramic &amp; Graphene Coating</Badge>
          <h1 className="max-w-xl text-balance font-display text-4xl font-bold leading-tight text-white sm:text-5xl">
            Protection that outlasts the season — and the paint.
          </h1>
          <p className="mt-5 max-w-lg text-lg text-white/75">
            Nano-ceramic and graphene coatings, professionally applied after full paint correction, with 1-year and
            5+ year warrantied options.
          </p>
          <div className="mt-8">
            <ButtonLink href="/contact" variant="accent" size="lg">
              Get a coating quote
            </ButtonLink>
          </div>
        </Container>
      </header>

      <section className="py-20 sm:py-24">
        <Container>
          <SectionHeading eyebrow="Why coat your car" title="More than a shine — real, lasting protection" align="center" className="mx-auto" />
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {benefits.map((b) => (
              <Card key={b.title} className="p-6 text-center">
                <div className="mx-auto flex size-11 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <b.icon className="size-5" aria-hidden="true" />
                </div>
                <h3 className="mt-4 font-display text-base font-semibold text-foreground">{b.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{b.description}</p>
              </Card>
            ))}
          </div>
        </Container>
      </section>

      <section className="bg-card py-20 sm:py-24">
        <Container>
          <SectionHeading eyebrow="Our process" title="Correction first. Coating second. Every time." description="Skipping correction is the #1 reason DIY ceramic coatings fail early — we never coat over unprepped paint." />
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {process.map((p) => (
              <div key={p.step} className="rounded-xl border border-border bg-background p-6">
                <span className="font-display text-3xl font-bold text-primary/30">{p.step}</span>
                <h3 className="mt-3 font-display text-base font-semibold text-foreground">{p.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{p.description}</p>
              </div>
            ))}
          </div>
        </Container>
      </section>

      <section className="py-20 sm:py-24">
        <Container>
          <SectionHeading eyebrow="Packages" title="Ceramic coating pricing" description="Starting-at pricing by vehicle size; final price confirmed after inspection." />
          <div className="mt-12 grid gap-6 lg:grid-cols-2">
            {paintCorrectionPackages.map((pkg) => (
              <Card key={pkg.name} className="flex flex-col p-7">
                <h3 className="font-display text-xl font-semibold text-foreground">{pkg.name}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{pkg.description}</p>
                <div className="mt-6 grid grid-cols-3 gap-3 rounded-lg bg-muted p-4 text-center">
                  {(Object.keys(vehicleTierLabels) as Array<keyof typeof vehicleTierLabels>).map((tier) => (
                    <div key={tier}>
                      <p className="font-display text-lg font-bold text-foreground">${pkg.price[tier]}</p>
                      <p className="mt-1 text-[11px] leading-tight text-muted-foreground">{vehicleTierLabels[tier]}</p>
                    </div>
                  ))}
                </div>
                <ul className="mt-6 flex-1 space-y-2.5 text-sm text-foreground">
                  {pkg.includes.map((line) => (
                    <li key={line} className="flex items-start gap-2">
                      <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden="true" />
                      {line}
                    </li>
                  ))}
                </ul>
              </Card>
            ))}
          </div>
          <p className="mt-8 text-center text-sm text-muted-foreground">
            We&apos;re also a certified installer for Glassparency windshield &amp; glass coatings — ask when you book.
          </p>
        </Container>
      </section>

      <section className="pb-24">
        <Container>
          <div className="flex flex-col items-center gap-5 rounded-2xl bg-primary px-8 py-14 text-center text-white">
            <h2 className="max-w-lg text-balance font-display text-3xl font-bold sm:text-4xl">
              Lock in years of protection this season.
            </h2>
            <ButtonLink href="/contact" variant="accent" size="lg">
              Book my ceramic coating
            </ButtonLink>
          </div>
        </Container>
      </section>
    </>
  );
}
