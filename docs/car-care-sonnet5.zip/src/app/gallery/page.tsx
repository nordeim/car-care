import type { Metadata } from "next";
import Image from "next/image";
import { Badge, ButtonLink, Container, SectionHeading } from "@/components/ui";

export const metadata: Metadata = {
  title: "Gallery",
  description: "Recent detailing, ceramic coating, and mobile detailing work from We Care Car Care in Framingham, MA.",
};

const galleryItems = [
  {
    src: "/images/gallery-1.jpg",
    alt: "White SUV being hand-washed with foam suds in the detailing studio bay",
    caption: "Foam pre-soak hand wash — every detail starts here",
  },
  {
    src: "/images/gallery-2.jpg",
    alt: "Detailer steam-cleaning beige leather car seats",
    caption: "Steam sanitizing lifts stains other methods can't touch",
  },
  {
    src: "/images/gallery-3.jpg",
    alt: "Detailer applying ceramic coating with a suede applicator block",
    caption: "Hand-applied ceramic coating, cross-hatch technique",
  },
  {
    src: "/images/gallery-4.jpg",
    alt: "Mobile detailing van set up in a suburban driveway",
    caption: "Mobile detailing — we bring the studio to your driveway",
  },
  {
    src: "/images/hero-detailing.jpg",
    alt: "Detailer hand-polishing the hood of a glossy sedan",
    caption: "Single-stage machine polish before coating",
  },
  {
    src: "/images/ceramic-coating-hero.jpg",
    alt: "Macro shot of water beading on a ceramic-coated hood",
    caption: "The payoff: hydrophobic, self-cleaning gloss",
  },
];

export default function GalleryPage() {
  return (
    <>
      <header className="border-b border-border bg-card py-16 sm:py-20">
        <Container>
          <Badge className="mb-4">Gallery</Badge>
          <h1 className="max-w-2xl text-balance font-display text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
            See the difference in every detail.
          </h1>
          <p className="mt-4 max-w-xl text-lg text-muted-foreground">
            A look inside our studio process — from first wash to final ceramic gloss.
          </p>
        </Container>
      </header>

      <section className="py-16 sm:py-20">
        <Container>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {galleryItems.map((item) => (
              <figure key={item.src} className="group relative aspect-4/3 overflow-hidden rounded-xl border border-border">
                <Image
                  src={item.src}
                  alt={item.alt}
                  fill
                  className="object-cover transition-transform duration-500 ease-out group-hover:scale-105"
                  sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"
                />
                <figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink/90 to-transparent p-4 text-sm font-medium text-white">
                  {item.caption}
                </figcaption>
              </figure>
            ))}
          </div>

          <div className="mt-14 flex flex-col items-center gap-5 rounded-2xl border border-border bg-card px-8 py-12 text-center">
            <SectionHeading title="Want results like these on your car?" align="center" className="mx-auto" />
            <ButtonLink href="/contact" variant="primary" size="lg">
              Book your detail
            </ButtonLink>
          </div>
        </Container>
      </section>
    </>
  );
}
