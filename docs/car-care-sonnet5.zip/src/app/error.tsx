"use client";

import { useEffect } from "react";
import { ButtonLink, Button, Container } from "@/components/ui";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("[app/error]", { message: error.message, digest: error.digest });
  }, [error]);

  return (
    <Container className="flex min-h-[60vh] flex-col items-center justify-center gap-5 py-24 text-center">
      <p className="text-sm font-semibold uppercase tracking-[0.14em] text-primary">Something went wrong</p>
      <h1 className="font-display text-3xl font-bold text-foreground sm:text-4xl">
        We hit a snag loading this page.
      </h1>
      <p className="max-w-md text-muted-foreground">
        Please try again, or call us directly and we&apos;ll help you book over the phone.
      </p>
      <div className="flex flex-col gap-3 sm:flex-row">
        <Button variant="primary" onClick={() => reset()}>
          Try again
        </Button>
        <ButtonLink href="/" variant="outline">
          Back to home
        </ButtonLink>
      </div>
    </Container>
  );
}
