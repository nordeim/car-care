import type { Metadata } from "next";
import { Clock, Mail, MapPin, Phone } from "lucide-react";
import { Badge, Container } from "@/components/ui";
import { BookingForm } from "@/components/booking-form";
import { site } from "@/data/site";

export const metadata: Metadata = {
  title: "Contact & Booking",
  description: `Book a detailing appointment with ${site.name} in ${site.address.city}, ${site.address.region} — studio, mobile, or winter pickup & delivery.`,
};

export default function ContactPage() {
  return (
    <>
      <header className="border-b border-border bg-card py-16 sm:py-20">
        <Container>
          <Badge className="mb-4">Contact &amp; Booking</Badge>
          <h1 className="max-w-2xl text-balance font-display text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
            Let&apos;s get your car booked in.
          </h1>
          <p className="mt-4 max-w-xl text-lg text-muted-foreground">
            Fill out the form and we&apos;ll confirm your appointment within one business day — or call us directly
            for same-day scheduling.
          </p>
        </Container>
      </header>

      <section className="py-16 sm:py-20">
        <Container className="grid gap-12 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]">
          <div className="rounded-2xl border border-border bg-card p-6 sm:p-8">
            <BookingForm />
          </div>

          <div className="space-y-8">
            <InfoCard icon={Phone} title="Call or text">
              <a href={`tel:${site.phone}`} className="text-lg font-semibold text-primary hover:text-primary-600">
                {site.phoneDisplay}
              </a>
            </InfoCard>

            <InfoCard icon={Mail} title="Email">
              <a href={`mailto:${site.email}`} className="break-all text-base font-medium text-primary hover:text-primary-600">
                {site.email}
              </a>
            </InfoCard>

            <InfoCard icon={MapPin} title="Detailing studio">
              <p className="text-base text-foreground">
                {site.address.street}, {site.address.unit}
                <br />
                {site.address.city}, {site.address.region} {site.address.postalCode}
              </p>
              <p className="mt-2 text-sm text-muted-foreground">
                Secure two-way key drop available for 24/7 vehicle pickup &amp; drop-off.
              </p>
            </InfoCard>

            <InfoCard icon={Clock} title="Hours">
              <ul className="space-y-1 text-base text-foreground">
                {site.hours.map((h) => (
                  <li key={h.days} className="flex justify-between gap-4">
                    <span>{h.days}</span>
                    <span className="font-medium">{h.time}</span>
                  </li>
                ))}
              </ul>
            </InfoCard>

            <div className="rounded-xl border border-border bg-muted p-6">
              <h3 className="font-display text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                We also serve
              </h3>
              <div className="mt-3 flex flex-wrap gap-2">
                {site.serviceAreas.map((area) => (
                  <span key={area} className="rounded-full bg-card px-3 py-1 text-xs font-medium text-muted-foreground">
                    {area}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </Container>
      </section>
    </>
  );
}

function InfoCard({
  icon: Icon,
  title,
  children,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-xl border border-border bg-card p-6">
      <div className="flex items-center gap-3">
        <div className="flex size-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
          <Icon className="size-4.5" />
        </div>
        <h3 className="font-display text-sm font-semibold uppercase tracking-wide text-muted-foreground">{title}</h3>
      </div>
      <div className="mt-3">{children}</div>
    </div>
  );
}
