import { ButtonLink, Container } from "@/components/ui";

export default function NotFound() {
  return (
    <Container className="flex min-h-[60vh] flex-col items-center justify-center gap-5 py-24 text-center">
      <p className="font-display text-6xl font-bold text-primary/30">404</p>
      <h1 className="font-display text-3xl font-bold text-foreground sm:text-4xl">Page not found</h1>
      <p className="max-w-md text-muted-foreground">
        The page you&apos;re looking for may have moved. Try one of the links below.
      </p>
      <div className="flex flex-col gap-3 sm:flex-row">
        <ButtonLink href="/" variant="primary">
          Back to home
        </ButtonLink>
        <ButtonLink href="/services" variant="outline">
          View services
        </ButtonLink>
      </div>
    </Container>
  );
}
