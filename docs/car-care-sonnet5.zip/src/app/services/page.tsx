import type { Metadata } from "next";
import { CheckCircle2, ShieldCheck, Timer } from "lucide-react";
import { ButtonLink, Card, Container, SectionHeading, Badge } from "@/components/ui";
import { ServiceIcon } from "@/components/service-icon";
import { services } from "@/data/services";
import { detailingPackages, paintCorrectionPackages, upgradeAddOns, vehicleTierLabels } from "@/data/packages";
import { cn } from "@/lib/utils";

export const metadata: Metadata = {
  title: "Detailing Services & Pricing",
  description:
    "Explore We Care Car Care's full detailing menu — Essential, Plus, and Premium details, paint correction, ceramic coating, and mobile detailing pricing in Framingham & MetroWest MA.",
};

export default function ServicesPage() {
  return (
    <>
      <header className="border-b border-border bg-card py-16 sm:py-20">
        <Container>
          <Badge className="mb-4">Services &amp; Pricing</Badge>
          <h1 className="max-w-2xl text-balance font-display text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
            Every detail, priced upfront.
          </h1>
          <p className="mt-4 max-w-xl text-lg text-muted-foreground">
            All prices are &ldquo;starting at&rdquo; and may vary with vehicle condition. We&apos;ll always confirm the
            final price with you before we begin work.
          </p>
        </Container>
      </header>

      <section className="py-16 sm:py-20">
        <Container className="space-y-16">
          {services.map((service) => (
            <div key={service.slug} id={service.slug} className="grid gap-8 border-t border-border pt-12 first:border-0 first:pt-0 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
              <div>
                <div className="flex size-11 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <ServiceIcon icon={service.icon} className="size-5" />
                </div>
                <h2 className="mt-5 font-display text-2xl font-semibold text-foreground">{service.name}</h2>
                <p className="mt-1 text-sm font-semibold text-primary">{service.tagline}</p>
                <p className="mt-4 text-base leading-relaxed text-muted-foreground">{service.description}</p>
                <div className="mt-5 flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  <Timer className="size-3.5" aria-hidden="true" />
                  Typical duration: {service.durationHint}
                </div>
              </div>
              <ul className="space-y-3 rounded-xl border border-border bg-card p-6">
                {service.bullets.map((bullet) => (
                  <li key={bullet} className="flex items-start gap-2.5 text-sm text-foreground">
                    <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden="true" />
                    {bullet}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </Container>
      </section>

      <section className="bg-ink py-20 text-white sm:py-24">
        <Container>
          <SectionHeading
            eyebrow="Studio pricing"
            title="Full-service detailing packages"
            className="text-white"
            titleClassName="text-white"
          />
          <PricingGrid packages={detailingPackages} dark />
        </Container>
      </section>

      <section className="py-20 sm:py-24">
        <Container>
          <SectionHeading
            eyebrow="Paint correction & protection"
            title="Ceramic & graphene coating packages"
            description="Single-stage machine correction, topped with a warrantied coating that keeps your paint protected for years."
          />
          <PricingGrid packages={paintCorrectionPackages} />

          <div className="mt-10 rounded-xl border border-border bg-card p-6">
            <h3 className="font-display text-lg font-semibold text-foreground">Popular add-ons</h3>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              {upgradeAddOns.map((addon) => (
                <div key={addon.name} className="flex items-center justify-between rounded-lg border border-border px-4 py-3">
                  <span className="text-sm font-medium text-foreground">{addon.name}</span>
                  <span className="text-sm font-semibold text-primary">
                    ${addon.price.sedanCoupe}–${addon.price.truckSuvVan}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </Container>
      </section>

      <section className="pb-24">
        <Container>
          <div className="flex flex-col items-center gap-5 rounded-2xl border border-border bg-card px-8 py-12 text-center">
            <ShieldCheck className="size-8 text-primary" aria-hidden="true" />
            <h2 className="max-w-lg text-balance font-display text-2xl font-bold text-foreground sm:text-3xl">
              Not sure which package is right for your car?
            </h2>
            <p className="max-w-md text-muted-foreground">
              Tell us about your vehicle and we&apos;ll recommend the right service — no pressure, no upsell.
            </p>
            <ButtonLink href="/contact" variant="primary" size="lg">
              Get a personalized recommendation
            </ButtonLink>
          </div>
        </Container>
      </section>
    </>
  );
}

function PricingGrid({
  packages,
  dark,
}: {
  packages: typeof detailingPackages;
  dark?: boolean;
}) {
  return (
    <div className="mt-12 grid gap-6 lg:grid-cols-2">
      {packages.map((pkg) => (
        <Card
          key={pkg.name}
          className={cn(
            "flex flex-col p-7",
            dark && "border-white/10 bg-white/[0.04] text-white",
            dark && pkg.featured && "border-accent bg-white/[0.07] shadow-lift",
            !dark && pkg.featured && "border-primary/40 shadow-lift",
          )}
        >
          {pkg.featured ? (
            <Badge className={cn("mb-4 w-fit", dark && "border-accent/40 bg-accent/10 text-accent")}>
              Most popular
            </Badge>
          ) : null}
          <h3 className={cn("font-display text-xl font-semibold", dark ? "text-white" : "text-foreground")}>
            {pkg.name}
          </h3>
          <p className={cn("mt-2 text-sm", dark ? "text-white/60" : "text-muted-foreground")}>{pkg.description}</p>
          <div className={cn("mt-6 grid grid-cols-3 gap-3 rounded-lg p-4 text-center", dark ? "bg-white/5" : "bg-muted")}>
            {(Object.keys(vehicleTierLabels) as Array<keyof typeof vehicleTierLabels>).map((tier) => (
              <div key={tier}>
                <p className={cn("font-display text-lg font-bold", dark ? "text-white" : "text-foreground")}>
                  ${pkg.price[tier]}
                </p>
                <p className={cn("mt-1 text-[11px] leading-tight", dark ? "text-white/50" : "text-muted-foreground")}>
                  {vehicleTierLabels[tier]}
                </p>
              </div>
            ))}
          </div>
          <ul className={cn("mt-6 flex-1 space-y-2.5 text-sm", dark ? "text-white/80" : "text-foreground")}>
            {pkg.includes.map((line) => (
              <li key={line} className="flex items-start gap-2">
                <CheckCircle2 className={cn("mt-0.5 size-4 shrink-0", dark ? "text-accent" : "text-primary")} aria-hidden="true" />
                {line}
              </li>
            ))}
          </ul>
        </Card>
      ))}
    </div>
  );
}
