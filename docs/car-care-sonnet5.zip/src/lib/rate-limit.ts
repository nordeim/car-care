/**
 * Minimal in-memory sliding-window rate limiter, keyed per caller (e.g. IP).
 * Good enough for a single-instance Next.js deployment; swap for a shared
 * store (Redis/Upstash) if the app ever runs across multiple instances.
 */

interface Bucket {
  hits: number[];
}

const buckets = new Map<string, Bucket>();

const MAX_BUCKETS = 5000;

export interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  resetAtMs: number;
}

export function rateLimit(key: string, limit: number, windowMs: number): RateLimitResult {
  const now = Date.now();
  const windowStart = now - windowMs;

  let bucket = buckets.get(key);
  if (!bucket) {
    // Evict the oldest entries once the map grows unbounded (defends against
    // IP-spoofing floods that would otherwise leak memory indefinitely).
    if (buckets.size >= MAX_BUCKETS) {
      const oldestKey = buckets.keys().next().value;
      if (oldestKey !== undefined) buckets.delete(oldestKey);
    }
    bucket = { hits: [] };
    buckets.set(key, bucket);
  }

  bucket.hits = bucket.hits.filter((t) => t > windowStart);

  if (bucket.hits.length >= limit) {
    return { allowed: false, remaining: 0, resetAtMs: bucket.hits[0] + windowMs };
  }

  bucket.hits.push(now);
  return { allowed: true, remaining: limit - bucket.hits.length, resetAtMs: now + windowMs };
}

export function getClientIp(headers: Headers): string {
  const forwardedFor = headers.get("x-forwarded-for");
  if (forwardedFor) return forwardedFor.split(",")[0]!.trim();
  const realIp = headers.get("x-real-ip");
  if (realIp) return realIp.trim();
  return "local";
}
