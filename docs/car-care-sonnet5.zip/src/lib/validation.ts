import { z } from "zod";

/** ZIP: 5-digit US postal code. */
const ZIP_RE = /^\d{5}$/;
/** Loose but safe phone matcher — accepts common US formats. */
const PHONE_RE = /^[\d\s()+.-]{7,20}$/;

export const serviceInterestValues = [
  "essential_detail",
  "plus_detail",
  "premium_detail",
  "ceramic_coating",
  "mobile_detailing",
  "not_sure",
] as const;

export const vehicleTypeValues = ["sedan_coupe", "crossover_suv", "truck_suv_van", "other"] as const;

export const bookingSchema = z.object({
  fullName: z.string().trim().min(2, "Enter your full name").max(120),
  email: z.string().trim().email("Enter a valid email address").max(200),
  phone: z.string().trim().regex(PHONE_RE, "Enter a valid phone number"),
  zipCode: z.string().trim().regex(ZIP_RE, "Enter a 5-digit ZIP code"),
  vehicleType: z.enum(vehicleTypeValues),
  serviceInterest: z.enum(serviceInterestValues),
  preferredDate: z.string().trim().max(40).optional().or(z.literal("")),
  message: z.string().trim().max(2000).optional().or(z.literal("")),
  /**
   * Honeypot field — hidden from real users via CSS. Left unconstrained here
   * so a filled-in value still passes validation; the route handler checks
   * it and silently no-ops instead of revealing the trap with a 400.
   */
  companyWebsite: z.string().max(500).optional().or(z.literal("")),
});

export type BookingInput = z.infer<typeof bookingSchema>;
